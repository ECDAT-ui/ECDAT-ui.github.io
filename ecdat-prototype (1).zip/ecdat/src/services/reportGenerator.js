import { label } from './pqcRecommendationEngine.js';
import { csvCell } from './cbomGenerator.js';

export function summarise(artefacts) {
  const s = {
    total: artefacts.length,
    applications: new Set(artefacts.map(a => a.application)).size,
    critical: artefacts.filter(a => a.risk.level === 'CRITICAL').length,
    high: artefacts.filter(a => a.risk.level === 'HIGH').length,
    medium: artefacts.filter(a => a.risk.level === 'MEDIUM').length,
    low: artefacts.filter(a => a.risk.level === 'LOW').length,
    quantumVulnerable: artefacts.filter(a => a.risk.quantumVulnerable).length,
    pqcReady: artefacts.filter(a => a.pqc).length,
    certificates: artefacts.filter(a => a.primitive === 'certificate').length,
    libraries: new Set(artefacts.map(a => a.library).filter(l => l && l !== 'Not identified')).size,
    deprecated: artefacts.filter(a => ['MD5', 'SHA-1', 'DES', '3DES', 'RC4', 'SSL'].includes(a.algorithm)).length,
    avgRisk: artefacts.length ? Math.round(artefacts.reduce((x, a) => x + a.risk.score, 0) / artefacts.length) : 0
  };
  s.migrationCandidates = artefacts.filter(a => !a.pqc && (a.risk.quantumVulnerable || a.risk.score >= 55)).length;
  return s;
}

export function executiveReport(artefacts, mosca, meta) {
  const s = summarise(artefacts);
  const top = artefacts.slice(0, 5);
  const byApp = groupRisk(artefacts);
  const lines = [];
  lines.push('ECDAT — EXECUTIVE CRYPTOGRAPHIC POSTURE REPORT');
  lines.push('='.repeat(64));
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push(`Data source: ${meta.source}${meta.demo ? '  (FICTIONAL DEMO DATASET)' : ''}`);
  lines.push('Prototype demonstrating automated cryptographic discovery, inventory, quantum-risk assessment and migration prioritisation. Not a production assurance tool.');
  lines.push('');
  lines.push('1. OVERALL POSTURE');
  lines.push(`   Artefacts discovered      : ${s.total} across ${s.applications} application(s)`);
  lines.push(`   Average risk score        : ${s.avgRisk}/100`);
  lines.push(`   Critical / High           : ${s.critical} / ${s.high}`);
  lines.push(`   Quantum-vulnerable        : ${s.quantumVulnerable} (${pct(s.quantumVulnerable, s.total)})`);
  lines.push(`   Deprecated primitives     : ${s.deprecated}`);
  lines.push(`   Already post-quantum      : ${s.pqcReady}`);
  lines.push(`   Migration candidates      : ${s.migrationCandidates}`);
  lines.push('');
  lines.push('2. QUANTUM EXPOSURE (MOSCA-STYLE ASSESSMENT)');
  lines.push(`   ${mosca.statement}`);
  lines.push(`   ${mosca.verdict}`);
  lines.push('   Assumptions are user-configurable; this is a planning aid, not a prediction of quantum timelines.');
  lines.push('');
  lines.push('3. HIGHEST-PRIORITY MIGRATION AREAS');
  top.forEach(a => {
    lines.push(`   P${a.priorityRank}. ${label(a)} — ${a.application} (${a.environment})`);
    lines.push(`        Risk ${a.risk.score}/100 (${a.risk.level}) | Priority ${a.priorityScore}/100 | ${a.priorityBand}`);
    lines.push(`        Location: ${a.file}:${a.line}`);
    lines.push(`        Action: ${a.recommendation.action}`);
  });
  lines.push('');
  lines.push('4. RISK BY APPLICATION');
  byApp.forEach(r => lines.push(`   ${pad(r.application, 26)} artefacts=${pad(r.count, 4)} avg risk=${pad(r.avg, 4)} critical=${r.critical}`));
  lines.push('');
  lines.push('5. RECOMMENDED NEXT STEPS');
  lines.push('   a. Remove classically broken primitives (MD5, SHA-1, DES/3DES, RC4, SSL) — these are immediate defects.');
  lines.push('   b. Enable hybrid key establishment (X25519 + ML-KEM) at TLS terminators to reduce harvest-now-decrypt-later exposure.');
  lines.push('   c. Start certificate-lifecycle work early; CA and client support has the longest lead time.');
  lines.push('   d. Pilot ML-DSA signatures on a non-critical service to measure size and performance impact.');
  lines.push('   e. Re-run discovery in CI so the inventory stays current.');
  return lines.join('\n');
}

export function technicalReport(artefacts, cbom, mosca, meta) {
  const lines = [];
  lines.push('ECDAT — TECHNICAL CRYPTOGRAPHIC ANALYSIS REPORT');
  lines.push('='.repeat(64));
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push(`Source: ${meta.source}${meta.demo ? '  (FICTIONAL DEMO DATASET)' : ''}`);
  lines.push(`Files scanned: ${cbom.metadata.filesScanned} | Lines scanned: ${cbom.metadata.linesScanned}`);
  lines.push('');
  lines.push('SECTION A — RISK METHODOLOGY');
  lines.push('score = Σ(normalised factor × weight); quantumVulnerability=35, algorithmStrength=20,');
  lines.push('businessCriticality=20, dataLifetime=12, exposure=8, migrationComplexity=5. Bands: LOW<35, MEDIUM<55, HIGH<75, CRITICAL≥75.');
  lines.push('');
  lines.push('SECTION B — MOSCA-STYLE ASSESSMENT');
  lines.push(`${mosca.statement}  →  ${mosca.actionRequired ? 'MIGRATION PLANNING REQUIRED' : 'SLACK AVAILABLE'}`);
  lines.push(mosca.verdict);
  lines.push('');
  lines.push('SECTION C — FULL INVENTORY WITH RISK DERIVATION');
  artefacts.forEach(a => {
    lines.push('-'.repeat(64));
    lines.push(`${a.id}  ${label(a)}  [${a.primitive}]`);
    lines.push(`  Application : ${a.application} (${a.environment}, criticality=${a.criticality}, exposure=${a.exposure})`);
    lines.push(`  Location    : ${a.file}:${a.line}  (${a.language})`);
    lines.push(`  Library     : ${a.library}${a.libraryVersion ? ' ' + a.libraryVersion : ''}`);
    lines.push(`  Usage       : ${a.usage}`);
    lines.push(`  Detection   : rule="${a.ruleId}" match="${a.matchedText}" confidence=${a.confidence}`);
    lines.push(`  Risk        : ${a.risk.score}/100 (${a.risk.level})  quantum-vulnerable=${a.risk.quantumVulnerable}`);
    a.risk.factors.forEach(f => lines.push(`     + ${pad(f.key, 24)} ${pad(f.points, 5)} / ${f.max}   ${f.rationale}`));
    lines.push(`  Priority    : ${a.priorityScore}/100  rank #${a.priorityRank}  ${a.priorityBand}`);
    lines.push(`  Recommend   : ${a.recommendation.action}`);
    if (a.recommendation.transition) lines.push(`     transition: ${a.recommendation.transition}`);
    if (a.recommendation.target) lines.push(`     target    : ${a.recommendation.target}`);
    if (a.recommendation.performanceNote) lines.push(`     perf      : ${a.recommendation.performanceNote}`);
  });
  lines.push('');
  lines.push('SECTION D — MIGRATION ROADMAP');
  roadmap(artefacts).forEach(p => {
    lines.push(`  ${p.phase}. ${p.name} — ${p.status} (${p.detail})`);
  });
  lines.push('');
  lines.push('SECTION E — LIMITATIONS');
  lines.push('  Pattern-based detection only; no dataflow analysis, no binary/runtime inspection, no live network or certificate-store scanning.');
  lines.push('  Business criticality, data lifetime and exposure are supplied metadata, not measured values.');
  return lines.join('\n');
}

export function inventoryCSV(artefacts) {
  const head = ['ID', 'Algorithm', 'KeySize', 'Usage', 'Application', 'Environment', 'Library', 'File', 'Line', 'Language', 'Confidence', 'RiskScore', 'RiskLevel', 'QuantumVulnerable', 'PriorityScore', 'PriorityBand', 'RecommendedAction'];
  const rows = artefacts.map(a => [a.id, label(a), a.keySize ?? '', a.usage, a.application, a.environment, a.library, a.file, a.line, a.language, a.confidence, a.risk.score, a.risk.level, a.risk.quantumVulnerable, a.priorityScore, a.priorityBand, a.recommendation.action]);
  return [head, ...rows].map(r => r.map(csvCell).join(',')).join('\n');
}

export function roadmap(artefacts) {
  const s = summarise(artefacts);
  return [
    { phase: 1, name: 'Discover', status: s.total ? 'Complete' : 'Not started', detail: `${s.total} artefacts across ${s.applications} application(s)` },
    { phase: 2, name: 'Assess', status: s.total ? 'Complete' : 'Blocked', detail: `average risk ${s.avgRisk}/100; ${s.quantumVulnerable} quantum-vulnerable` },
    { phase: 3, name: 'Prioritise', status: s.total ? 'Complete' : 'Blocked', detail: `${artefacts.filter(a => a.priorityScore >= 70).length} artefact(s) in band P1` },
    { phase: 4, name: 'Pilot', status: s.migrationCandidates ? 'Recommended next' : 'Not required', detail: `${s.migrationCandidates} migration candidate(s); start with TLS key establishment` },
    { phase: 5, name: 'Migrate', status: 'Planned', detail: `${s.deprecated} deprecated primitive(s) can be removed before any PQC work` },
    { phase: 6, name: 'Validate', status: 'Planned', detail: 'Interoperability, signature-size and handshake-latency testing' },
    { phase: 7, name: 'Monitor', status: 'Planned', detail: 'Re-run discovery in CI to detect cryptographic drift' }
  ];
}

export function groupRisk(artefacts) {
  const m = new Map();
  artefacts.forEach(a => {
    if (!m.has(a.application)) m.set(a.application, []);
    m.get(a.application).push(a);
  });
  return [...m.entries()].map(([application, list]) => ({
    application, count: list.length,
    avg: Math.round(list.reduce((s, a) => s + a.risk.score, 0) / list.length),
    critical: list.filter(a => a.risk.level === 'CRITICAL').length,
    high: list.filter(a => a.risk.level === 'HIGH').length,
    quantumVulnerable: list.filter(a => a.risk.quantumVulnerable).length
  })).sort((a, b) => b.avg - a.avg);
}

function pct(n, d) { return d ? Math.round((n / d) * 100) + '%' : '0%'; }
function pad(v, n) { return String(v).padEnd(n); }
