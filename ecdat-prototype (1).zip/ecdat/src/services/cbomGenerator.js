import { label } from './pqcRecommendationEngine.js';

/**
 * Generates a cryptography bill of materials.
 * NOTE: the layout is *inspired by* CycloneDX cryptographic-asset concepts.
 * This prototype does not claim CycloneDX schema conformance or validation.
 */
export function generateCBOM(analysis, meta = {}) {
  const components = analysis.artefacts.map(a => ({
    'bom-ref': a.id,
    name: label(a),
    type: 'cryptographic-asset',
    cryptoProperties: {
      assetType: a.primitive,
      algorithm: a.algorithm,
      variant: a.variant || null,
      keySize: a.keySize || null,
      curve: a.curve || null,
      mode: a.mode || null,
      primitive: a.primitive,
      postQuantum: a.pqc
    },
    protocol: a.protocol,
    certificate: a.certificate,
    library: { name: a.library, version: a.libraryVersion },
    usage: a.usage,
    occurrence: { file: a.file, line: a.line, language: a.language, matchedText: a.matchedText, detectionConfidence: a.confidence },
    application: a.application,
    environment: a.environment,
    dependencies: a.dependencies || [],
    risk: { score: a.risk.score, level: a.risk.level, quantumVulnerable: a.risk.quantumVulnerable },
    recommendation: {
      action: a.recommendation.action,
      transition: a.recommendation.transition,
      target: a.recommendation.target,
      family: a.recommendation.family
    }
  }));

  return {
    bomFormat: 'ECDAT-CBOM',
    specVersionNote: 'Prototype structure inspired by CycloneDX cryptographic-asset concepts; not schema-validated.',
    version: 1,
    metadata: {
      timestamp: new Date().toISOString(),
      tool: { vendor: 'ECDAT prototype', name: 'Enterprise Cryptographic Discovery & Analysis Tool', version: '0.9.0-prototype' },
      dataSource: meta.source || 'unknown',
      demoData: !!meta.demo,
      filesScanned: analysis.filesScanned,
      linesScanned: analysis.linesScanned
    },
    components,
    libraries: analysis.libraries
  };
}

export function cbomToCSV(cbom) {
  const head = ['bom-ref', 'name', 'assetType', 'algorithm', 'keySize', 'curve', 'mode', 'library', 'libraryVersion', 'usage', 'application', 'environment', 'file', 'line', 'confidence', 'riskScore', 'riskLevel', 'quantumVulnerable', 'transition', 'target'];
  const rows = cbom.components.map(c => [
    c['bom-ref'], c.name, c.cryptoProperties.assetType, c.cryptoProperties.algorithm, c.cryptoProperties.keySize ?? '',
    c.cryptoProperties.curve ?? '', c.cryptoProperties.mode ?? '', c.library.name, c.library.version ?? '', c.usage,
    c.application, c.environment, c.occurrence.file, c.occurrence.line, c.occurrence.detectionConfidence,
    c.risk.score, c.risk.level, c.risk.quantumVulnerable, c.recommendation.transition ?? '', c.recommendation.target ?? ''
  ]);
  return [head, ...rows].map(r => r.map(csvCell).join(',')).join('\n');
}

export function csvCell(v) {
  const s = String(v ?? '');
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
