/**
 * Maps a discovered artefact to a migration recommendation.
 * Recommendations are advisory: they depend on primitive, use case, performance
 * sensitivity and compatibility, and are NOT automatic drop-in replacements.
 */

export function recommend(a, risk) {
  const base = { current: label(a), transition: null, target: null, family: null, action: '', notes: [], compatibility: 'medium', performanceNote: '' };

  switch (a.primitive) {
    case 'key-establishment':
      return {
        ...base, family: 'ML-KEM (FIPS 203)',
        transition: `${a.algorithm} + ML-KEM-768 (hybrid)`,
        target: 'ML-KEM-768',
        action: 'Adopt a hybrid key-establishment mode first so classical interoperability is preserved while post-quantum confidentiality is added.',
        compatibility: 'requires peer support; hybrid groups are widely deployed in TLS 1.3',
        performanceNote: 'Larger handshake messages (~1.1 KB public key); usually acceptable, verify on constrained/IoT links.',
        notes: ['Key establishment is the highest priority for harvest-now-decrypt-later exposure.']
      };
    case 'public-key':
    case 'signature': {
      const isSig = a.primitive === 'signature' || /sign/i.test(a.usage || '');
      if (a.pqc) return { ...base, target: a.algorithm, action: 'Already a post-quantum primitive. Verify parameter set and library maturity.', family: a.algorithm };
      if (isSig) {
        const longLived = (a.dataLifetimeYears ?? 5) >= 10 || a.primitive === 'certificate';
        return {
          ...base,
          family: longLived ? 'ML-DSA (FIPS 204), consider SLH-DSA (FIPS 205) for long-lived roots' : 'ML-DSA (FIPS 204)',
          transition: `${a.algorithm} + ML-DSA-65 (hybrid/composite signature)`,
          target: longLived ? 'ML-DSA-65, with SLH-DSA-SHA2-128s for long-lived trust anchors' : 'ML-DSA-65',
          action: 'Plan a hybrid/composite signature transition; validate signature-size impact on protocols and storage before cutover.',
          compatibility: 'verifier-side support required across the whole trust chain',
          performanceNote: 'ML-DSA signatures are ~3.3 KB vs ~64 B for ECDSA P-256; SLH-DSA is larger still but relies only on hash security.',
          notes: longLived ? ['Long data lifetime or trust-anchor role favours a conservative hash-based option for the root.'] : []
        };
      }
      return {
        ...base, family: 'ML-KEM (FIPS 203) for encryption/key transport, ML-DSA (FIPS 204) for signing',
        transition: `${a.algorithm} + ML-KEM-768 or ML-DSA-65 depending on the confirmed use case`,
        target: 'Use-case dependent — confirm whether this call performs key transport or signing before choosing.',
        action: 'Manual triage required: the detected API can serve either key transport or signature. Confirm the use case, then select ML-KEM or ML-DSA.',
        compatibility: 'unknown until use case is confirmed',
        notes: ['Detection could not determine the use case unambiguously.']
      };
    }
    case 'symmetric-cipher': {
      if (['DES', '3DES', 'RC4'].includes(a.algorithm)) {
        return { ...base, family: 'AES-256-GCM or ChaCha20-Poly1305', target: 'AES-256-GCM', action: 'Replace immediately: this is a classical weakness, not merely a quantum one. No PQC algorithm is needed here.', compatibility: 'high', performanceNote: 'Hardware-accelerated on most platforms.' };
      }
      if (a.algorithm === 'AES' && a.keySize === 128) {
        return { ...base, family: 'AES (symmetric)', target: 'AES-256-GCM', action: 'Increase key length to 256 bits to restore margin against generic quantum search. No lattice algorithm is required for symmetric encryption.', compatibility: 'high', performanceNote: 'Minor throughput cost on some platforms.' };
      }
      if (a.mode === 'ECB') return { ...base, family: 'AEAD mode', target: 'AES-256-GCM', action: 'Replace ECB with an authenticated mode (GCM) — this is a correctness/security defect independent of quantum risk.', compatibility: 'high' };
      return { ...base, family: 'AES (symmetric)', target: `${label(a)} — retain`, action: 'No post-quantum replacement required. Keep under review and ensure keys are ≥256 bits.', compatibility: 'high' };
    }
    case 'hash':
      if (['MD5', 'SHA-1'].includes(a.algorithm)) return { ...base, family: 'SHA-2 / SHA-3', target: 'SHA-256 or SHA-384', action: 'Replace now: broken for collision resistance classically. For password storage use Argon2id instead of a bare hash.', compatibility: 'high' };
      return { ...base, family: 'SHA-2 / SHA-3', target: (a.variant && parseInt(a.variant) >= 384) ? `SHA-${a.variant} — retain` : 'SHA-384 where long-term collision resistance is required', action: 'Generally acceptable. Consider longer digests where documents must remain verifiable for decades.', compatibility: 'high' };
    case 'mac':
      return { ...base, family: 'HMAC / KMAC', target: 'HMAC-SHA-256 with ≥256-bit keys', action: 'No post-quantum replacement required; ensure key length is at least 256 bits.', compatibility: 'high' };
    case 'kdf':
      if (a.algorithm === 'PBKDF2') return { ...base, family: 'Argon2id', target: 'Argon2id', action: 'Migrate password hashing to Argon2id with tuned memory cost; if PBKDF2 must remain, raise iteration counts.', compatibility: 'medium — requires rehash-on-login strategy' };
      return { ...base, family: a.algorithm, target: `${a.algorithm} — retain`, action: 'Acceptable. Review cost parameters annually.', compatibility: 'high' };
    case 'protocol':
      if (a.algorithm === 'SSL' || ['1.0', '1.1'].includes(a.variant)) return { ...base, family: 'TLS 1.3', target: 'TLS 1.3 with hybrid key exchange', action: 'Disable the deprecated protocol version first, then enable a hybrid (X25519+ML-KEM) key-exchange group.', compatibility: 'medium' };
      return { ...base, family: 'TLS 1.3 hybrid key exchange', transition: 'TLS 1.3 with X25519MLKEM768 hybrid group', target: 'TLS 1.3 with ML-KEM key establishment and PQC certificates', action: 'Enable hybrid key exchange at terminators/load balancers — usually the cheapest early win.', compatibility: 'high on modern stacks', performanceNote: 'Slightly larger ClientHello; check middlebox tolerance.' };
    case 'certificate':
      return { ...base, family: 'PQC / composite certificates', transition: 'Composite or dual-certificate deployment', target: 'ML-DSA certificate chain', action: 'Inventory issuance and rotation first; certificate migration depends on CA support and typically has the longest lead time.', compatibility: 'low — gated by CA and client support', notes: ['Certificate lifecycle work should start early even if cutover is late.'] };
    default:
      return { ...base, family: 'Manual review', target: 'To be determined', action: 'Manual triage required — the prototype could not classify this artefact confidently.' };
  }
}

export function label(a) {
  if (a.keySize && ['RSA'].includes(a.algorithm)) return `${a.algorithm}-${a.keySize}`;
  if (a.algorithm === 'AES' && a.keySize) return `AES-${a.keySize}${a.mode ? '-' + a.mode : ''}`;
  if (a.algorithm === 'SHA-2' && a.variant) return `SHA-${a.variant}`;
  if (a.curve) return `${a.algorithm} ${a.curve}`;
  if (a.variant) return `${a.algorithm} ${a.variant}`;
  return a.algorithm;
}
