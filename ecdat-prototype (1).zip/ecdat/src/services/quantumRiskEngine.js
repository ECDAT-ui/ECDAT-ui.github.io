/**
 * Deterministic quantum risk scoring engine.
 *
 * Score = QV(0-35) + AS(0-20) + BC(0-20) + DL(0-12) + EX(0-8) + MC(0-5)  => 0..100
 * Every component is derived from artefact attributes; nothing is random.
 */

export const WEIGHTS = {
  quantumVulnerability: 35,
  algorithmStrength: 20,
  businessCriticality: 20,
  dataLifetime: 12,
  exposure: 8,
  migrationComplexity: 5
};

// Normalised 0..1 quantum vulnerability per algorithm family.
// Rationale strings are shown verbatim in the "Explain Risk" panel.
const QV = {
  'RSA': [1.0, "Public-key scheme whose security rests on integer factorisation; Shor's algorithm breaks it on a cryptographically relevant quantum computer (CRQC)."],
  'ECDSA': [1.0, "Elliptic-curve signature based on the discrete log problem; broken by Shor's algorithm on a CRQC."],
  'ECDH': [1.0, "Elliptic-curve key agreement based on the discrete log problem; broken by Shor's algorithm. Also exposed to harvest-now-decrypt-later."],
  'ECC': [1.0, 'Elliptic-curve public-key material; discrete-log based and therefore quantum-vulnerable.'],
  'Diffie-Hellman': [1.0, "Finite-field key agreement based on the discrete log problem; broken by Shor's algorithm."],
  'Ed25519/X25519': [1.0, 'Modern curve-based primitives, classically strong but still discrete-log based and therefore quantum-vulnerable.'],
  'JWT Signing': [0.8, 'Token signing typically uses RSA or ECDSA (RS256/ES256/PS256), which are quantum-vulnerable. HS256 is symmetric and far less affected.'],
  'DES': [0.35, 'Symmetric cipher; Grover gives only a quadratic speed-up, but DES is already classically broken which dominates the risk.'],
  '3DES': [0.35, 'Symmetric cipher with ~112-bit effective strength; classical weaknesses and block size dominate over quantum concerns.'],
  'RC4': [0.3, 'Symmetric stream cipher; classically broken, quantum impact secondary.'],
  'AES': [0.25, 'Symmetric cipher. Grover-style search gives at most a quadratic speed-up, so AES-256 retains a large margin; AES-128 has a reduced margin.'],
  'ChaCha20-Poly1305': [0.2, 'Symmetric AEAD with a 256-bit key; retains a substantial margin against generic quantum search.'],
  'SHA-2': [0.25, 'Hash function. Generic quantum collision/pre-image speed-ups reduce the effective margin; SHA-256 remains acceptable, longer digests give more headroom.'],
  'SHA-3': [0.2, 'Hash function with good margins; quantum speed-ups are generic only.'],
  'SHA-1': [0.45, 'Classically broken for collision resistance; quantum considerations are secondary to the existing classical break.'],
  'MD5': [0.5, 'Classically broken; must not be used for security purposes regardless of quantum considerations.'],
  'HMAC': [0.15, 'MAC built on a hash; security depends on key length and is only mildly affected by generic quantum search.'],
  'PBKDF2': [0.2, 'Password-based KDF; quantum search lowers the effective work factor, iteration counts matter more.'],
  'bcrypt': [0.18, 'Password hashing; memory/time hardness matters more than quantum speed-ups.'],
  'scrypt': [0.15, 'Memory-hard password hashing; limited quantum exposure.'],
  'Argon2': [0.1, 'Modern memory-hard password hashing; limited quantum exposure.'],
  'TLS': [0.85, 'Transport protocol whose handshake normally relies on quantum-vulnerable key establishment and signatures.'],
  'SSL': [0.95, 'Legacy transport protocol; deprecated, classically insecure and reliant on quantum-vulnerable key exchange.'],
  'X.509 Certificate': [0.9, 'Certificates carry quantum-vulnerable public keys and signatures and must be re-issued during PQC migration.'],
  'Key Material Reference': [0.6, 'Stored key material whose algorithm may be quantum-vulnerable; requires manual confirmation.'],
  'ML-KEM': [0.0, 'NIST-standardised post-quantum key encapsulation mechanism; not affected by Shor.'],
  'ML-DSA': [0.0, 'NIST-standardised post-quantum lattice signature; not affected by Shor.'],
  'SLH-DSA': [0.0, 'NIST-standardised stateless hash-based signature; conservative post-quantum security.']
};

function quantumVulnerability(a) {
  let [v, rationale] = QV[a.algorithm] || [0.5, 'Algorithm family not in the rule set; assigned a neutral default pending manual review.'];
  if (a.algorithm === 'AES') {
    if (a.keySize === 128) { v = 0.35; rationale += ' AES-128 detected: reduced post-quantum margin.'; }
    if (a.keySize === 256) { v = 0.12; rationale += ' AES-256 detected: large post-quantum margin.'; }
  }
  if (a.algorithm === 'SHA-2') {
    const d = parseInt(a.variant || '256', 10);
    if (d <= 224) { v = 0.4; rationale += ' Short digest reduces margin.'; }
    else if (d >= 384) { v = 0.12; rationale += ' Long digest gives ample margin.'; }
  }
  if (a.algorithm === 'TLS' && a.variant === '1.3') { v = 0.7; rationale += ' TLS 1.3 detected: modern handshake, but still classical key establishment.'; }
  if (a.algorithm === 'TLS' && (a.variant === '1.0' || a.variant === '1.1')) { v = 0.95; rationale += ' Deprecated TLS version detected.'; }
  return { value: v, rationale };
}

function algorithmStrength(a) {
  // 0 = strong for its class, 1 = weak / deprecated
  let v = 0.3, why = 'Parameters are within commonly accepted ranges for classical security.';
  if (['MD5', 'SHA-1', 'DES', 'RC4', 'SSL'].includes(a.algorithm)) { v = 1.0; why = 'Algorithm is deprecated or classically broken and should be removed irrespective of quantum risk.'; }
  else if (a.algorithm === '3DES') { v = 0.85; why = 'Effective ~112-bit strength with a 64-bit block size; deprecated for new use.'; }
  else if (a.algorithm === 'RSA') {
    if (!a.keySize) { v = 0.6; why = 'RSA detected but key size could not be determined from the source; treat as unknown-strength.'; }
    else if (a.keySize <= 1024) { v = 1.0; why = 'RSA-1024 is below accepted classical strength.'; }
    else if (a.keySize <= 2048) { v = 0.45; why = 'RSA-2048 is classically acceptable today but offers no post-quantum margin.'; }
    else { v = 0.3; why = `RSA-${a.keySize} is classically strong, but larger keys do not mitigate Shor.`; }
  } else if (a.algorithm === 'AES') {
    v = a.keySize === 128 ? 0.4 : a.keySize ? 0.1 : 0.45;
    why = a.keySize ? `AES-${a.keySize} detected.` : 'AES detected without an explicit key size.';
    if (a.mode === 'ECB') { v = 1.0; why = 'AES in ECB mode detected: ECB does not provide semantic security.'; }
  } else if (['ECDSA', 'ECDH', 'ECC'].includes(a.algorithm)) {
    v = (a.keySize && a.keySize >= 192) ? 0.25 : 0.4;
    why = a.curve ? `Curve ${a.curve} provides roughly ${a.keySize || '?'}-bit classical security.` : 'Curve parameters not fully determined.';
  } else if (a.algorithm === 'PBKDF2') { v = 0.5; why = 'PBKDF2 is acceptable but weaker than memory-hard alternatives such as Argon2id.'; }
  else if (['Argon2', 'scrypt', 'ML-KEM', 'ML-DSA', 'SLH-DSA', 'ChaCha20-Poly1305'].includes(a.algorithm)) { v = 0.05; why = 'Modern primitive with strong parameters.'; }
  return { value: v, rationale: why };
}

const CRIT = { critical: 1.0, high: 0.75, medium: 0.5, low: 0.25 };
const EXPO = { 'internet-facing': 1.0, partner: 0.7, internal: 0.4, isolated: 0.15 };

const COMPLEXITY = {
  protocol: 0.9, certificate: 0.95, 'public-key': 0.8, signature: 0.8,
  'key-establishment': 0.7, 'symmetric-cipher': 0.35, hash: 0.3, mac: 0.3, kdf: 0.25, 'key-material': 0.6
};

export function scoreArtefact(a) {
  const qv = quantumVulnerability(a);
  const as = algorithmStrength(a);
  const bc = CRIT[a.criticality] ?? 0.5;
  const dl = Math.min(1, (a.dataLifetimeYears ?? 5) / 15);
  const ex = EXPO[a.exposure] ?? 0.4;
  const depBoost = Math.min(0.3, (a.dependencies?.length || 0) * 0.06);
  const mc = Math.min(1, (COMPLEXITY[a.primitive] ?? 0.5) + depBoost);

  const factors = [
    { key: 'Quantum vulnerability', points: round(qv.value * WEIGHTS.quantumVulnerability), max: WEIGHTS.quantumVulnerability, rationale: qv.rationale },
    { key: 'Algorithm strength', points: round(as.value * WEIGHTS.algorithmStrength), max: WEIGHTS.algorithmStrength, rationale: as.rationale },
    { key: 'Business criticality', points: round(bc * WEIGHTS.businessCriticality), max: WEIGHTS.businessCriticality, rationale: `Component criticality recorded as "${a.criticality}".` },
    { key: 'Data lifetime', points: round(dl * WEIGHTS.dataLifetime), max: WEIGHTS.dataLifetime, rationale: `Protected data lifetime of ${a.dataLifetimeYears ?? 5} year(s); long lifetimes increase harvest-now-decrypt-later exposure.` },
    { key: 'Exposure', points: round(ex * WEIGHTS.exposure), max: WEIGHTS.exposure, rationale: `Deployment exposure recorded as "${a.exposure}".` },
    { key: 'Migration complexity', points: round(mc * WEIGHTS.migrationComplexity), max: WEIGHTS.migrationComplexity, rationale: `Primitive type "${a.primitive}" with ${a.dependencies?.length || 0} recorded dependency/dependencies; complex changes need earlier planning.` }
  ];

  const score = Math.max(0, Math.min(100, Math.round(factors.reduce((s, f) => s + f.points, 0))));
  return {
    score,
    level: levelFor(score),
    quantumVulnerable: qv.value >= 0.7,
    factors,
    formula: 'score = Σ (normalised factor × weight), weights: ' + Object.entries(WEIGHTS).map(([k, v]) => `${k}=${v}`).join(', ')
  };
}

export function levelFor(score) {
  if (score >= 75) return 'CRITICAL';
  if (score >= 55) return 'HIGH';
  if (score >= 35) return 'MEDIUM';
  return 'LOW';
}

function round(n) { return Math.round(n * 10) / 10; }

/** Mosca-style decision: migrationYears + dataLifetimeYears > threatHorizonYears */
export function mosca({ migrationYears, dataLifetimeYears, threatHorizonYears }) {
  const total = migrationYears + dataLifetimeYears;
  const gap = round(total - threatHorizonYears);
  return {
    migrationYears, dataLifetimeYears, threatHorizonYears, total, gap,
    actionRequired: total > threatHorizonYears,
    statement: `${dataLifetimeYears} (data lifetime) + ${migrationYears} (migration time) = ${total} ${total > threatHorizonYears ? '>' : '≤'} ${threatHorizonYears} (assumed threat horizon)`,
    verdict: total > threatHorizonYears
      ? `Under these assumptions there is a ${gap}-year shortfall. Migration planning should begin now.`
      : `Under these assumptions there is ${Math.abs(gap)} year(s) of slack, but assumptions should be revisited regularly.`
  };
}
