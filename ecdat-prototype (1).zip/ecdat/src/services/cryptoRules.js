// Detection rules for the ECDAT prototype discovery engine.
// Each rule is a regex + metadata. Rules are ordered: more specific first.
// `confidence` reflects how unambiguous the pattern is, not vendor accuracy claims.

export const LANG_BY_EXT = {
  py: 'Python', js: 'JavaScript', mjs: 'JavaScript', ts: 'TypeScript', tsx: 'TypeScript',
  java: 'Java', c: 'C', h: 'C', cpp: 'C++', hpp: 'C++', go: 'Go', rs: 'Rust',
  php: 'PHP', cs: 'C#', json: 'JSON', yaml: 'YAML', yml: 'YAML', conf: 'Config',
  cnf: 'Config', ini: 'Config', env: 'Config', tf: 'Terraform', xml: 'XML', properties: 'Config'
};

export const SCANNABLE_EXT = Object.keys(LANG_BY_EXT);

// primitive: one of key-encapsulation | signature | symmetric-cipher | hash | mac | kdf | protocol | certificate | library
export const RULES = [
  // ---- Asymmetric / public key ----
  { id: 'rsa-sized', re: /RSA[-_ ]?(1024|2048|3072|4096)/i, algorithm: 'RSA', primitive: 'public-key', keySizeFrom: 1, confidence: 0.97, usage: 'Key Establishment / Signature' },
  { id: 'rsa-keygen-py', re: /rsa\.generate_private_key\s*\([^)]*key_size\s*=\s*(\d{3,5})/i, algorithm: 'RSA', primitive: 'public-key', keySizeFrom: 1, confidence: 0.98, usage: 'Key Generation', library: 'python-cryptography' },
  { id: 'rsa-import-py', re: /asymmetric\s+import\s+[^\n]*\brsa\b|from\s+Crypto\.PublicKey\s+import\s+RSA/i, algorithm: 'RSA', primitive: 'public-key', confidence: 0.94, usage: 'Asymmetric Operation', library: 'python-cryptography' },
  { id: 'rsa-java', re: /KeyPairGenerator\.getInstance\(\s*"RSA"|Cipher\.getInstance\(\s*"RSA/i, algorithm: 'RSA', primitive: 'public-key', confidence: 0.95, usage: 'Asymmetric Operation', library: 'Java Cryptography Architecture' },
  { id: 'rsa-openssl', re: /RSA_generate_key(_ex)?|EVP_PKEY_RSA|genrsa/i, algorithm: 'RSA', primitive: 'public-key', confidence: 0.93, usage: 'Key Generation', library: 'OpenSSL' },
  { id: 'rsa-generic', re: /\bRSA\b/, algorithm: 'RSA', primitive: 'public-key', confidence: 0.72, usage: 'Asymmetric Operation' },

  { id: 'ecdsa-curve', re: /ECDSA[^\n]{0,24}?(P-?256|P-?384|P-?521|secp256r1|secp384r1|prime256v1)|(?:P-?256|secp256r1|prime256v1)[^\n]{0,24}?ECDSA/i, algorithm: 'ECDSA', primitive: 'signature', curveFrom: 0, confidence: 0.96, usage: 'Digital Signature' },
  { id: 'ecdsa', re: /\bECDSA\b|ec\.ECDSA|SHA256withECDSA/i, algorithm: 'ECDSA', primitive: 'signature', confidence: 0.93, usage: 'Digital Signature' },
  { id: 'ecdh', re: /\bECDHE?\b|ECDH_compute_key|ec\.ECDH/i, algorithm: 'ECDH', primitive: 'key-establishment', confidence: 0.93, usage: 'Key Establishment' },
  { id: 'curve', re: /\b(secp256r1|secp384r1|prime256v1|secp256k1|P-256|P-384)\b/i, algorithm: 'ECC', primitive: 'public-key', curveFrom: 1, confidence: 0.9, usage: 'Elliptic Curve Parameter' },
  { id: 'ed25519', re: /\bEd25519\b|X25519/i, algorithm: 'Ed25519/X25519', primitive: 'public-key', confidence: 0.94, usage: 'Signature / Key Establishment' },
  { id: 'ecc', re: /\bECC\b|elliptic[_ ]curve/i, algorithm: 'ECC', primitive: 'public-key', confidence: 0.8, usage: 'Asymmetric Operation' },
  { id: 'dh', re: /Diffie[- ]?Hellman|\bDHE?\b_|dh_generate|DH_new/i, algorithm: 'Diffie-Hellman', primitive: 'key-establishment', confidence: 0.9, usage: 'Key Establishment' },

  // ---- PQC ----
  { id: 'mlkem', re: /\bML-?KEM\b|Kyber(512|768|1024)?/i, algorithm: 'ML-KEM', primitive: 'key-establishment', pqc: true, confidence: 0.95, usage: 'Post-Quantum Key Establishment' },
  { id: 'mldsa', re: /\bML-?DSA\b|Dilithium\d?/i, algorithm: 'ML-DSA', primitive: 'signature', pqc: true, confidence: 0.95, usage: 'Post-Quantum Signature' },
  { id: 'slhdsa', re: /\bSLH-?DSA\b|SPHINCS\+?/i, algorithm: 'SLH-DSA', primitive: 'signature', pqc: true, confidence: 0.95, usage: 'Post-Quantum Signature' },

  // ---- Symmetric ----
  { id: 'aes-sized', re: /AES[-_ ]?(128|192|256)(?:[-_ ]?(GCM|CBC|CTR|ECB|CCM))?/i, algorithm: 'AES', primitive: 'symmetric-cipher', keySizeFrom: 1, modeFrom: 2, confidence: 0.96, usage: 'Data Encryption' },
  { id: 'aes-java', re: /Cipher\.getInstance\(\s*"AES\/(\w+)\//i, algorithm: 'AES', primitive: 'symmetric-cipher', modeFrom: 1, confidence: 0.94, usage: 'Data Encryption', library: 'Java Cryptography Architecture' },
  { id: 'chacha', re: /ChaCha20(-Poly1305)?/i, algorithm: 'ChaCha20-Poly1305', primitive: 'symmetric-cipher', keySize: 256, confidence: 0.95, usage: 'Data Encryption' },
  { id: 'aes', re: /\bAES\b/, algorithm: 'AES', primitive: 'symmetric-cipher', confidence: 0.78, usage: 'Data Encryption' },
  { id: '3des', re: /3DES|TripleDES|DESede/i, algorithm: '3DES', primitive: 'symmetric-cipher', keySize: 112, confidence: 0.95, usage: 'Legacy Data Encryption' },
  { id: 'des', re: /\bDES\b(?!ede)/, algorithm: 'DES', primitive: 'symmetric-cipher', keySize: 56, confidence: 0.9, usage: 'Legacy Data Encryption' },
  { id: 'rc4', re: /\bRC4\b|ARCFOUR/i, algorithm: 'RC4', primitive: 'symmetric-cipher', keySize: 128, confidence: 0.92, usage: 'Legacy Stream Cipher' },

  // ---- Hash / MAC / KDF ----
  { id: 'hmac', re: /\bHMAC[-_]?(SHA[-_]?\d{1,3})?/i, algorithm: 'HMAC', primitive: 'mac', variantFrom: 1, confidence: 0.93, usage: 'Message Authentication' },
  { id: 'sha2', re: /SHA[-_ ]?(224|256|384|512)/i, algorithm: 'SHA-2', primitive: 'hash', variantFrom: 1, confidence: 0.94, usage: 'Hashing / Integrity' },
  { id: 'sha3', re: /SHA-?3[-_ ]?(224|256|384|512)?/i, algorithm: 'SHA-3', primitive: 'hash', variantFrom: 1, confidence: 0.94, usage: 'Hashing / Integrity' },
  { id: 'sha1', re: /SHA[-_ ]?1\b|sha1\(/i, algorithm: 'SHA-1', primitive: 'hash', confidence: 0.94, usage: 'Hashing / Integrity' },
  { id: 'md5', re: /\bMD5\b|md5\(/i, algorithm: 'MD5', primitive: 'hash', confidence: 0.95, usage: 'Hashing / Integrity' },
  { id: 'argon2', re: /Argon2(id|i|d)?/i, algorithm: 'Argon2', primitive: 'kdf', confidence: 0.96, usage: 'Password Hashing' },
  { id: 'bcrypt', re: /\bbcrypt\b/i, algorithm: 'bcrypt', primitive: 'kdf', confidence: 0.95, usage: 'Password Hashing' },
  { id: 'scrypt', re: /\bscrypt\b/i, algorithm: 'scrypt', primitive: 'kdf', confidence: 0.95, usage: 'Password Hashing' },
  { id: 'pbkdf2', re: /PBKDF2(WithHmacSHA\d+)?/i, algorithm: 'PBKDF2', primitive: 'kdf', confidence: 0.95, usage: 'Key Derivation' },

  // ---- Protocols / certificates ----
  { id: 'tls', re: /TLS(?:v)?[-_ ]?(1\.0|1\.1|1\.2|1\.3)/i, algorithm: 'TLS', primitive: 'protocol', variantFrom: 1, confidence: 0.95, usage: 'Transport Security' },
  { id: 'ssl', re: /SSLv?[23]|SSLv3/i, algorithm: 'SSL', primitive: 'protocol', confidence: 0.94, usage: 'Legacy Transport Security' },
  { id: 'cert', re: /BEGIN CERTIFICATE|x509|X\.509|\.pem\b|\.crt\b|certificate_path|ssl_certificate/i, algorithm: 'X.509 Certificate', primitive: 'certificate', confidence: 0.85, usage: 'Identity / Trust' },
  { id: 'key-material', re: /BEGIN (RSA |EC )?PRIVATE KEY|private_key_path|\.key\b/i, algorithm: 'Key Material Reference', primitive: 'key-material', confidence: 0.8, usage: 'Key Storage Reference' },
  { id: 'jwt', re: /\b(RS256|ES256|HS256|PS256)\b/, algorithm: 'JWT Signing', primitive: 'signature', variantFrom: 1, confidence: 0.93, usage: 'Token Signing' }
];

// Library detection (imports / package references)
export const LIBRARY_RULES = [
  { re: /from\s+cryptography\.|import\s+cryptography|cryptography==[\d.]+/i, name: 'python-cryptography', versionRe: /cryptography[=@ ]{1,2}([\d.]+)/i },
  { re: /import\s+OpenSSL|openssl\/(?:evp|rsa|ssl|des)\.h|libssl|OpenSSL\s+[\d.]+/i, name: 'OpenSSL', versionRe: /OpenSSL[ =v]{1,2}([\d.]+)/i },
  { re: /org\.bouncycastle|bcprov-jdk\w*[:-][\d.]+|BouncyCastle/i, name: 'Bouncy Castle', versionRe: /bcprov-jdk\w*[:-]([\d.]+)/i },
  { re: /libsodium|sodium_|import\s+nacl|PyNaCl/i, name: 'libsodium/NaCl' },
  { re: /javax\.crypto|java\.security/i, name: 'Java Cryptography Architecture' },
  { re: /require\(['"]crypto['"]\)|from\s+['"]node:crypto['"]|import\s+crypto\s+from/i, name: 'Node.js crypto' },
  { re: /crypto\/(tls|rsa|ecdsa|aes|sha256)"/i, name: 'Go crypto stdlib' },
  { re: /\buse\s+ring::|RustCrypto|aes-gcm\s*=|\brustls\b/i, name: 'RustCrypto/ring' },
  { re: /System\.Security\.Cryptography/i, name: '.NET Cryptography' },
  { re: /import\s+hashlib|hashlib\./i, name: 'Python hashlib' },
  { re: /Crypto\.(Cipher|PublicKey|Hash)/i, name: 'PyCryptodome' },
  { re: /\boqs\b|liboqs|open-quantum-safe/i, name: 'liboqs (PQC)' }
];

export function detectLibraries(text) {
  const found = new Map();
  for (const lr of LIBRARY_RULES) {
    const m = text.match(lr.re);
    if (m) {
      const vm = lr.versionRe ? text.match(lr.versionRe) : null;
      const version = vm ? vm[1] : null;
      if (!found.has(lr.name) || version) found.set(lr.name, version);
    }
  }
  return [...found.entries()].map(([name, version]) => ({ name, version }));
}
