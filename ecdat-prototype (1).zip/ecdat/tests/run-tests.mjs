import { runPipeline } from '../src/services/pipeline.js';
import { discover } from '../src/services/discoveryEngine.js';
import { scoreArtefact, mosca, levelFor } from '../src/services/quantumRiskEngine.js';
import { recommend } from '../src/services/pqcRecommendationEngine.js';
import { generateCBOM, cbomToCSV } from '../src/services/cbomGenerator.js';
import { inventoryCSV, executiveReport, technicalReport, summarise } from '../src/services/reportGenerator.js';
import { DEMO_FILES, DEMO_META } from '../src/data/demoDataset.js';

let pass = 0, fail = 0;
const t = (name, fn) => { try { fn(); console.log(`  PASS  ${name}`); pass++; } catch (e) { console.log(`  FAIL  ${name}\n        ${e.message}`); fail++; } };
const ok = (c, m) => { if (!c) throw new Error(m || 'assertion failed'); };
const file = (path, content) => [{ path, content, application: 'T', environment: 'Production', criticality: 'critical', dataLifetimeYears: 10, exposure: 'internet-facing', dependencies: ['a'] }];

console.log('\nECDAT engine tests\n');

t('1. RSA detection with key size and line number', () => {
  const r = discover(file('a/auth.py', 'x=1\nfrom cryptography.hazmat.primitives.asymmetric import rsa\nk = rsa.generate_private_key(public_exponent=65537, key_size=2048)\n'));
  const a = r.artefacts.find(x => x.algorithm === 'RSA' && x.keySize === 2048);
  ok(a, 'no RSA-2048 artefact');
  ok(a.line === 3, 'wrong line ' + a.line);
  ok(a.language === 'Python', 'wrong language');
  ok(a.confidence > 0.9, 'low confidence');
});

t('2. ECC / ECDSA / ECDH detection with curve', () => {
  const r = discover(file('b/tls.go', 'const C = "secp384r1"\n// ECDSA signing\nvar x = ECDH_compute_key\n'));
  ok(r.artefacts.some(a => a.algorithm === 'ECDSA'), 'no ECDSA');
  ok(r.artefacts.some(a => a.algorithm === 'ECDH'), 'no ECDH');
  const ec = r.artefacts.find(a => a.curve === 'secp384r1');
  ok(ec && ec.keySize === 192, 'curve strength not mapped');
});

t('3. AES detection distinguishes 128 from 256', () => {
  const r = discover(file('c/s.js', 'const A="AES-128-CBC";\nconst B="AES-256-GCM";\n'));
  const a128 = r.artefacts.find(a => a.keySize === 128);
  const a256 = r.artefacts.find(a => a.keySize === 256);
  ok(a128 && a128.mode === 'CBC', 'AES-128-CBC missing');
  ok(a256 && a256.mode === 'GCM', 'AES-256-GCM missing');
});

t('4. SHA / MD5 detection', () => {
  const r = discover(file('d/h.py', 'hashlib.sha256(x)\nhashlib.md5(y)\nSHA-1\n'));
  ok(r.artefacts.some(a => a.algorithm === 'SHA-2' && a.variant === '256'), 'no SHA-256');
  ok(r.artefacts.some(a => a.algorithm === 'MD5'), 'no MD5');
  ok(r.artefacts.some(a => a.algorithm === 'SHA-1'), 'no SHA-1');
});

t('5. Cryptographic library detection with version', () => {
  const r = discover(file('e/req.txt.py', 'import OpenSSL\nfrom cryptography.hazmat.primitives import hashes\ncryptography==42.0.5\norg.bouncycastle.x\n'));
  const names = r.libraries.map(l => l.name);
  ok(names.includes('OpenSSL'), 'OpenSSL not detected');
  ok(names.includes('python-cryptography'), 'python-cryptography not detected');
  ok(names.includes('Bouncy Castle'), 'Bouncy Castle not detected');
  ok(r.libraries.find(l => l.name === 'python-cryptography').version === '42.0.5', 'version not captured');
});

t('6. Risk scoring is deterministic, bounded and explained', () => {
  const a = { algorithm: 'RSA', keySize: 2048, primitive: 'public-key', criticality: 'critical', dataLifetimeYears: 12, exposure: 'internet-facing', dependencies: ['x', 'y'], usage: 'Digital Signature' };
  const r1 = scoreArtefact(a), r2 = scoreArtefact(a);
  ok(r1.score === r2.score, 'not deterministic');
  ok(r1.score >= 0 && r1.score <= 100, 'out of bounds');
  ok(r1.factors.length === 6, 'missing factors');
  const sum = r1.factors.reduce((s, f) => s + f.points, 0);
  ok(Math.abs(sum - r1.score) <= 1, 'factors do not sum to score');
  ok(r1.level === levelFor(r1.score), 'level mismatch');
  ok(r1.quantumVulnerable === true, 'RSA should be quantum-vulnerable');
});

t('6b. AES-256 scores lower than RSA-2048 and AES-128', () => {
  const base = { criticality: 'critical', dataLifetimeYears: 12, exposure: 'internet-facing', dependencies: [] };
  const rsa = scoreArtefact({ ...base, algorithm: 'RSA', keySize: 2048, primitive: 'public-key' }).score;
  const a256 = scoreArtefact({ ...base, algorithm: 'AES', keySize: 256, primitive: 'symmetric-cipher' }).score;
  const a128 = scoreArtefact({ ...base, algorithm: 'AES', keySize: 128, primitive: 'symmetric-cipher' }).score;
  ok(a256 < a128, 'AES-256 should score below AES-128');
  ok(a128 < rsa, 'AES-128 should score below RSA-2048');
  ok(!scoreArtefact({ ...base, algorithm: 'AES', keySize: 256, primitive: 'symmetric-cipher' }).quantumVulnerable, 'AES-256 must not be flagged quantum-vulnerable');
});

t('7. CBOM generation and CSV export', () => {
  const res = runPipeline(DEMO_FILES, DEMO_META);
  ok(res.cbom.components.length === res.artefacts.length, 'component count mismatch');
  const c = res.cbom.components[0];
  ok(c['bom-ref'] && c.cryptoProperties.algorithm && c.risk.level, 'missing CBOM fields');
  const csv = cbomToCSV(res.cbom);
  ok(csv.split('\n').length === res.artefacts.length + 1, 'CSV row count wrong');
  ok(csv.startsWith('bom-ref,name,'), 'CSV header wrong');
});

t('8. PQC recommendations are use-case dependent', () => {
  const kem = recommend({ algorithm: 'ECDH', primitive: 'key-establishment', usage: 'Key Establishment', dataLifetimeYears: 10 });
  ok(/ML-KEM/.test(kem.target), 'ECDH should map to ML-KEM');
  ok(/hybrid/i.test(kem.transition), 'ECDH should have hybrid transition');
  const sig = recommend({ algorithm: 'ECDSA', primitive: 'signature', usage: 'Digital Signature', dataLifetimeYears: 5 });
  ok(/ML-DSA/.test(sig.target), 'ECDSA should map to ML-DSA');
  const aes = recommend({ algorithm: 'AES', keySize: 256, primitive: 'symmetric-cipher' });
  ok(!/ML-KEM|ML-DSA/.test(aes.target), 'AES-256 must not be told to use a PQC KEM');
  const longLived = recommend({ algorithm: 'RSA', primitive: 'certificate', usage: 'Identity', dataLifetimeYears: 20 });
  ok(/composite|ML-DSA/i.test(longLived.target || longLived.action), 'certificate path missing');
});

t('9. Migration prioritisation ranks by weighted score, not alphabet', () => {
  const res = runPipeline(DEMO_FILES, DEMO_META);
  ok(res.artefacts[0].priorityRank === 1, 'rank not assigned');
  for (let i = 1; i < res.artefacts.length; i++) ok(res.artefacts[i - 1].priorityScore >= res.artefacts[i].priorityScore, 'not sorted at index ' + i);
  const critApp = res.artefacts[0];
  ok(['critical', 'high'].includes(critApp.criticality), 'top priority should be a critical/high system');
  ok(res.artefacts[0].priorityBand.startsWith('P1'), 'top band should be P1');
});

t('10. Export functions produce non-trivial output', () => {
  const res = runPipeline(DEMO_FILES, DEMO_META);
  const m = mosca({ migrationYears: 4, dataLifetimeYears: 10, threatHorizonYears: 12 });
  ok(m.actionRequired === true, 'mosca 10+4>12 should require action');
  ok(mosca({ migrationYears: 2, dataLifetimeYears: 3, threatHorizonYears: 15 }).actionRequired === false, 'mosca slack case wrong');
  ok(inventoryCSV(res.artefacts).split('\n').length === res.artefacts.length + 1, 'inventory CSV wrong');
  const ex = executiveReport(res.artefacts, m, DEMO_META);
  ok(ex.includes('EXECUTIVE') && ex.includes('MOSCA'), 'executive report incomplete');
  const tech = technicalReport(res.artefacts, res.cbom, m, DEMO_META);
  ok(tech.includes('SECTION C') && tech.includes('Quantum vulnerability'), 'technical report incomplete');
  ok(JSON.stringify(res.cbom).length > 1000, 'CBOM JSON too small');
});

t('11. Demo dataset produces a realistic spread', () => {
  const res = runPipeline(DEMO_FILES, DEMO_META);
  const s = summarise(res.artefacts);
  ok(s.total >= 30, 'too few artefacts: ' + s.total);
  ok(s.applications === 7, 'expected 7 applications, got ' + s.applications);
  ok(s.critical > 0 && s.high > 0 && s.low > 0, `needs a spread of levels: ${JSON.stringify(s)}`);
  ok(s.pqcReady > 0, 'demo should include at least one PQC artefact');
  ok(s.deprecated > 0, 'demo should include deprecated primitives');
  ok(res.artefacts.every(a => a.risk.score >= 0 && a.priorityScore >= 0 && a.file && a.line > 0), 'artefact fields incomplete');
});

console.log(`\n${pass} passed, ${fail} failed\n`);
process.exit(fail ? 1 : 0);
