import { RULES, LANG_BY_EXT, detectLibraries } from './cryptoRules.js';

const CURVE_STRENGTH = { 'P-256': 128, 'secp256r1': 128, 'prime256v1': 128, 'secp256k1': 128, 'P-384': 192, 'secp384r1': 192, 'P-521': 256 };

export function languageOf(path) {
  const ext = (path.split('.').pop() || '').toLowerCase();
  return LANG_BY_EXT[ext] || 'Unknown';
}

function isCommentNoise(line) {
  // Reduce confidence for matches that appear only inside prose comments.
  return /^\s*(#|\/\/|\*|<!--)/.test(line);
}

/**
 * Scan a set of files and produce cryptographic artefact records.
 * @param {Array<{path:string, content:string, application?:string, environment?:string, criticality?:string, dataLifetimeYears?:number, exposure?:string}>} files
 * @param {{source?:string}} opts
 */
export function discover(files, opts = {}) {
  const artefacts = [];
  const librariesByApp = new Map();
  let counter = 0;

  for (const file of files) {
    const language = languageOf(file.path);
    const libs = detectLibraries(file.content);
    const app = file.application || 'Uploaded Project';
    if (!librariesByApp.has(app)) librariesByApp.set(app, new Map());
    libs.forEach(l => librariesByApp.get(app).set(l.name, l.version));

    const lines = file.content.split(/\r?\n/);
    const seenPerFile = new Set();

    lines.forEach((line, idx) => {
      if (line.length > 4000) return;
      const claimed = []; // avoid a generic rule re-reporting what a specific rule already matched

      for (const rule of RULES) {
        rule.re.lastIndex = 0;
        const m = line.match(rule.re);
        if (!m) continue;
        const matchText = m[0];
        if (claimed.some(c => c.toLowerCase().includes(matchText.toLowerCase()) || matchText.toLowerCase().includes(c.toLowerCase()))) continue;
        claimed.push(matchText);

        let keySize = rule.keySize || null;
        if (rule.keySizeFrom != null && m[rule.keySizeFrom]) keySize = parseInt(m[rule.keySizeFrom], 10);

        let variant = null;
        if (rule.variantFrom != null && m[rule.variantFrom]) variant = m[rule.variantFrom].toUpperCase();
        let curve = null;
        if (rule.curveFrom != null) {
          const cm = matchText.match(/(P-?256|P-?384|P-?521|secp\d{3}[rk]1|prime256v1)/i);
          if (cm) curve = cm[1].replace(/^P(\d)/, 'P-$1');
        }
        if (curve && !keySize) keySize = CURVE_STRENGTH[curve] || CURVE_STRENGTH[curve?.replace('-', '')] || null;
        const mode = rule.modeFrom != null && m[rule.modeFrom] ? m[rule.modeFrom].toUpperCase() : null;

        // De-duplicate identical findings within one file (keep first occurrence)
        const dedupKey = `${rule.algorithm}|${variant || ''}|${keySize || ''}|${curve || ''}`;
        if (seenPerFile.has(dedupKey)) continue;
        seenPerFile.add(dedupKey);

        let confidence = rule.confidence;
        if (isCommentNoise(line)) confidence = Math.max(0.4, confidence - 0.25);

        counter += 1;
        const library = rule.library || libs[0]?.name || 'Not identified';
        artefacts.push({
          id: `CRYPTO-${String(counter).padStart(3, '0')}`,
          algorithm: rule.algorithm,
          variant: variant || curve || mode || null,
          keySize,
          curve,
          mode,
          primitive: rule.primitive,
          pqc: !!rule.pqc,
          library,
          libraryVersion: libs.find(l => l.name === library)?.version || null,
          file: file.path,
          line: idx + 1,
          snippet: lines.slice(Math.max(0, idx - 3), idx + 4).map((t, i) => ({ n: Math.max(1, idx - 2) + i, text: t })),
          matchedText: matchText,
          ruleId: rule.id,
          language,
          usage: rule.usage,
          protocol: rule.primitive === 'protocol' ? `${rule.algorithm}${variant ? ' ' + variant : ''}` : null,
          certificate: rule.primitive === 'certificate' ? matchText : null,
          environment: file.environment || 'Unspecified',
          application: app,
          criticality: file.criticality || 'medium',
          dataLifetimeYears: file.dataLifetimeYears ?? 5,
          exposure: file.exposure || 'internal',
          dependencies: file.dependencies || [],
          confidence: Math.round(confidence * 100) / 100,
          source: opts.source || 'upload',
          detectionReason: `Pattern rule "${rule.id}" matched "${matchText}" on line ${idx + 1} of ${file.path}.`
        });
      }
    });
  }

  const libraries = [];
  for (const [app, map] of librariesByApp) {
    for (const [name, version] of map) libraries.push({ application: app, name, version });
  }

  return {
    artefacts,
    libraries,
    filesScanned: files.length,
    linesScanned: files.reduce((a, f) => a + f.content.split(/\n/).length, 0),
    scannedAt: new Date().toISOString()
  };
}
