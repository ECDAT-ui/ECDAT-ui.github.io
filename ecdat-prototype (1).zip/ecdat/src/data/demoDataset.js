// FICTIONAL demo dataset. No real organisation, host, credential or key material.
// These are genuine source files that the discovery engine actually parses at runtime —
// the dashboard numbers are computed from this text, not hardcoded.

const APPS = {
  pay: { application: 'Payment Gateway', environment: 'Production', criticality: 'critical', dataLifetimeYears: 12, exposure: 'internet-facing', dependencies: ['Identity Service', 'Legacy Banking API', 'Fraud Engine'] },
  idp: { application: 'Identity Service', environment: 'Production', criticality: 'critical', dataLifetimeYears: 10, exposure: 'internet-facing', dependencies: ['Customer Portal', 'Payment Gateway'] },
  portal: { application: 'Customer Portal', environment: 'Production', criticality: 'high', dataLifetimeYears: 7, exposure: 'internet-facing', dependencies: ['Identity Service'] },
  legacy: { application: 'Legacy Banking API', environment: 'Production', criticality: 'critical', dataLifetimeYears: 15, exposure: 'partner', dependencies: ['Payment Gateway'] },
  hr: { application: 'Internal HR System', environment: 'Staging', criticality: 'medium', dataLifetimeYears: 6, exposure: 'internal', dependencies: [] },
  cloud: { application: 'Cloud Data Service', environment: 'Production', criticality: 'high', dataLifetimeYears: 14, exposure: 'partner', dependencies: ['Payment Gateway', 'Customer Portal'] },
  iot: { application: 'IoT Management Service', environment: 'Production', criticality: 'medium', dataLifetimeYears: 9, exposure: 'internet-facing', dependencies: ['Cloud Data Service'] }
};

function f(appKey, path, content) { return { ...APPS[appKey], path, content }; }

export const DEMO_FILES = [
  f('pay', 'payment-gateway/auth/service.py', `"""Payment authorisation signing service (demo)."""
import hashlib
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization

SIGNING_KEY_PATH = "/etc/pg/keys/signing.pem"   # certificate/key reference, no material stored

def generate_signing_key():
    # Settlement messages are signed with RSA-2048 for the acquirer network
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)

def sign_settlement(private_key, payload: bytes) -> bytes:
    digest = hashlib.sha256(payload).hexdigest()
    return private_key.sign(payload, padding.PKCS1v15(), hashes.SHA256())

def legacy_checksum(payload: bytes) -> str:
    # TODO: remove, retained for the 2011 acquirer batch format
    return hashlib.md5(payload).hexdigest()
`),
  f('pay', 'payment-gateway/config/tls.yaml', `server:
  tls_version: TLSv1.2
  ciphers: "ECDHE-RSA-AES128-GCM-SHA256:AES256-SHA"
  ssl_certificate: /etc/pg/certs/gateway.crt
  private_key_path: /etc/pg/certs/gateway.key
  curve: prime256v1
hsm:
  key_wrapping: AES-256-GCM
`),
  f('idp', 'identity-service/src/token.ts', `import crypto from "node:crypto";

// Access tokens are signed with ECDSA P-256 (ES256)
export const JWT_ALG = "ES256";

export function signToken(payload: object, privateKey: crypto.KeyObject) {
  const signer = crypto.createSign("SHA256");
  signer.update(JSON.stringify(payload));
  return signer.sign({ key: privateKey, dsaEncoding: "ieee-p1363" });
}

export function sessionMac(data: string, key: Buffer) {
  return crypto.createHmac("sha256", key).update(data).digest("hex");
}

export function deriveSessionKey(secret: Buffer, salt: Buffer) {
  return crypto.pbkdf2Sync(secret, salt, 120000, 32, "sha256");
}
`),
  f('idp', 'identity-service/src/passwords.java', `package com.demo.idp;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import org.bouncycastle.crypto.generators.Argon2BytesGenerator;

public class PasswordStore {
    // Modern path: Argon2id
    private static final String KDF = "Argon2id";

    // Legacy accounts migrated from the 2014 platform still verify with SHA-1
    private static final String LEGACY_DIGEST = "SHA-1";

    public byte[] wrapRecoveryCode(byte[] code) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        return c.doFinal(code);
    }

    public SecretKeyFactory legacyFactory() throws Exception {
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
    }
}
`),
  f('portal', 'customer-portal/server/session.js', `const crypto = require("crypto");

// Session cookies encrypted with AES-128-CBC (legacy, scheduled for upgrade)
const CIPHER = "AES-128-CBC";

function encryptSession(data, key, iv) {
  const c = crypto.createCipheriv(CIPHER, key, iv);
  return Buffer.concat([c.update(data), c.final()]);
}

function fingerprint(userAgent) {
  return crypto.createHash("sha256").update(userAgent).digest("hex");
}
module.exports = { encryptSession, fingerprint };
`),
  f('portal', 'customer-portal/nginx.conf', `server {
  ssl_protocols TLSv1.3 TLSv1.2;
  ssl_certificate /etc/nginx/certs/portal.pem;
  ssl_ciphers ECDHE-ECDSA-AES256-GCM-SHA384;
  ssl_ecdh_curve secp384r1;
}
`),
  f('legacy', 'legacy-banking-api/src/crypto_util.c', `#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/des.h>

/* Legacy mainframe interchange format, unchanged since 2004 */
static const char *INTERCHANGE_CIPHER = "3DES";

RSA *make_transport_key(void) {
    /* RSA-1024 transport key retained for partner compatibility */
    return RSA_generate_key(1024, RSA_F4, NULL, NULL);
}

void legacy_wrap(const unsigned char *in, unsigned char *out) {
    /* DES-EDE wrapping, deprecated */
    DES_ecb_encrypt((DES_cblock *)in, (DES_cblock *)out, NULL, DES_ENCRYPT);
}
`),
  f('legacy', 'legacy-banking-api/config/partner.properties', `partner.transport.protocol=SSLv3
partner.signature.algorithm=SHA1withRSA
partner.keystore=/opt/legacy/keys/partner.p12
partner.cert=/opt/legacy/certs/partner.crt
`),
  f('hr', 'hr-system/app/export.py', `import hashlib
from Crypto.Cipher import AES

# Payslip archive encryption (internal only)
ARCHIVE_CIPHER = "AES-256-GCM"

def archive_id(employee_id: str) -> str:
    return hashlib.sha256(employee_id.encode()).hexdigest()

def obsolete_index(value: str) -> str:
    return hashlib.md5(value.encode()).hexdigest()
`),
  f('cloud', 'cloud-data-service/storage/envelope.go', `package storage

import (
	"crypto/aes"
	"crypto/ecdsa"
	"crypto/rand"
	"crypto/sha512"
	"crypto/tls"
)

// Envelope encryption: AES-256 data keys wrapped by a KMS-held RSA-4096 key
const DataKeyAlgorithm = "AES-256-GCM"
const WrappingKey = "RSA-4096"

// Object manifests are signed with ECDSA P-384
func signManifest(key *ecdsa.PrivateKey, manifest []byte) ([]byte, error) {
	sum := sha512.Sum384(manifest)
	return ecdsa.SignASN1(rand.Reader, key, sum[:])
}

var tlsConf = &tls.Config{MinVersion: tls.VersionTLS13}
`),
  f('cloud', 'cloud-data-service/pqc/pilot.rs', `// PQC pilot branch — hybrid key establishment experiment
use oqs::kem::{Algorithm, Kem};

pub const HYBRID_GROUP: &str = "X25519MLKEM768";

pub fn pilot_kem() -> Kem {
    // ML-KEM-768 key encapsulation under evaluation
    Kem::new(Algorithm::Kyber768).expect("ML-KEM init")
}
`),
  f('iot', 'iot-management/firmware/provision.c', `#include <openssl/ssl.h>

/* Device provisioning over a constrained link */
#define DEVICE_CURVE     "secp256r1"   /* ECDH P-256 key agreement */
#define DEVICE_SIGNATURE "ECDSA"
#define FIRMWARE_HASH    "SHA-256"
#define SESSION_CIPHER   "ChaCha20-Poly1305"

/* Device identity certificates are issued from an internal X.509 CA */
static const char *DEVICE_CERT = "/data/certs/device.crt";
`),
  f('iot', 'iot-management/backend/registry.py', `from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes

# Device registry uses ECDH for session establishment and ECDSA for attestation
def device_session(private_key, peer_public):
    return private_key.exchange(ec.ECDH(), peer_public)

def verify_attestation(pubkey, sig, data):
    return pubkey.verify(sig, data, ec.ECDSA(hashes.SHA256()))
`)
];

export const DEMO_META = { source: 'Built-in enterprise demo dataset (fictional)', demo: true };
