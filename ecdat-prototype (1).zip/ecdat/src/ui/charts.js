// Dependency-free SVG charts. All render from live data; nothing is decorative.
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
export const RISK_COLOR = { CRITICAL: '#ff4d6a', HIGH: '#ff9f43', MEDIUM: '#f7d154', LOW: '#2ecc8f' };
const PALETTE = ['#3d8bfd', '#22d3a6', '#f7d154', '#ff9f43', '#ff4d6a', '#7b5bf0', '#4bc0ff', '#9aa7b8', '#e05fa8', '#5ad19b'];

export function barChart(data, { height = 220, color, horizontal = false, max } = {}) {
  if (!data.length) return emptyChart();
  const top = max || Math.max(...data.map(d => d.value), 1);
  if (horizontal) {
    return `<div style="display:flex;flex-direction:column;gap:9px">` + data.map((d, i) => `
      <div>
        <div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:3px">
          <span class="muted">${esc(d.label)}</span><span class="mono">${d.value}</span>
        </div>
        <div class="bar"><i style="width:${(d.value / top) * 100}%;background:${d.color || color || PALETTE[i % PALETTE.length]}"></i></div>
      </div>`).join('') + `</div>`;
  }
  const w = 100 / data.length;
  return `<svg viewBox="0 0 100 ${height / 3}" preserveAspectRatio="none" style="width:100%;height:${height}px;overflow:visible" role="img">
    ${data.map((d, i) => {
      const h = (d.value / top) * (height / 3 - 14);
      return `<rect x="${i * w + w * 0.18}" y="${height / 3 - 12 - h}" width="${w * 0.64}" height="${Math.max(h, 0.4)}" rx="0.7" fill="${d.color || color || PALETTE[i % PALETTE.length]}"><title>${esc(d.label)}: ${d.value}</title></rect>
      <text x="${i * w + w / 2}" y="${height / 3 - 15 - h}" font-size="3.1" fill="#8fa1ba" text-anchor="middle">${d.value}</text>
      <text x="${i * w + w / 2}" y="${height / 3 - 4}" font-size="2.9" fill="#63748f" text-anchor="middle">${esc(shorten(d.label, 13))}</text>`;
    }).join('')}
  </svg>`;
}

export function donut(data, { size = 190, label = '' } = {}) {
  const total = data.reduce((s, d) => s + d.value, 0);
  if (!total) return emptyChart();
  let acc = 0, r = 60, c = 2 * Math.PI * r;
  const arcs = data.map((d, i) => {
    const frac = d.value / total, dash = frac * c;
    const el = `<circle cx="80" cy="80" r="${r}" fill="none" stroke="${d.color || PALETTE[i % PALETTE.length]}" stroke-width="22"
      stroke-dasharray="${dash} ${c - dash}" stroke-dashoffset="${-acc}" transform="rotate(-90 80 80)"><title>${esc(d.label)}: ${d.value} (${Math.round(frac * 100)}%)</title></circle>`;
    acc += dash; return el;
  }).join('');
  return `<div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
    <svg viewBox="0 0 160 160" style="width:${size}px;height:${size}px;flex:none">${arcs}
      <text x="80" y="76" text-anchor="middle" font-size="24" fill="#e6edf6" font-weight="600">${total}</text>
      <text x="80" y="94" text-anchor="middle" font-size="9" fill="#63748f">${esc(label)}</text></svg>
    <div class="legend" style="flex-direction:column;gap:6px">
      ${data.map((d, i) => `<span><i style="background:${d.color || PALETTE[i % PALETTE.length]}"></i>${esc(d.label)} — ${d.value} (${Math.round(d.value / total * 100)}%)</span>`).join('')}
    </div></div>`;
}

export function stackedRows(rows) {
  if (!rows.length) return emptyChart();
  return `<div style="display:flex;flex-direction:column;gap:10px">` + rows.map(r => {
    const total = r.parts.reduce((s, p) => s + p.value, 0) || 1;
    return `<div><div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:3px">
      <span class="muted">${esc(r.label)}</span><span class="mono dim">${total}</span></div>
      <div style="display:flex;height:9px;border-radius:5px;overflow:hidden;background:#1b2536">
      ${r.parts.map(p => p.value ? `<span style="width:${p.value / total * 100}%;background:${p.color}" title="${esc(p.label)}: ${p.value}"></span>` : '').join('')}
      </div></div>`;
  }).join('') + `</div>`;
}

export function heatmap(rows, cols, get) {
  if (!rows.length) return emptyChart();
  return `<div class="tablewrap"><table class="heat" style="min-width:auto">
    <thead><tr><th>Application</th>${cols.map(c => `<th style="cursor:default">${esc(c)}</th>`).join('')}</tr></thead>
    <tbody>${rows.map(r => `<tr style="cursor:default"><td>${esc(r)}</td>${cols.map(c => {
      const v = get(r, c);
      return `<td class="cell" style="background:${v == null ? '#121924' : heatColor(v)};color:${v == null ? '#63748f' : '#0a0e14'}">${v == null ? '–' : v}</td>`;
    }).join('')}</tr>`).join('')}</tbody></table></div>
    <div class="legend"><span><i style="background:${heatColor(20)}"></i>low</span><span><i style="background:${heatColor(50)}"></i>medium</span><span><i style="background:${heatColor(70)}"></i>high</span><span><i style="background:${heatColor(90)}"></i>critical</span><span class="dim">cells show mean risk score</span></div>`;
}

export function heatColor(v) {
  if (v >= 75) return '#ff4d6a';
  if (v >= 55) return '#ff9f43';
  if (v >= 35) return '#f7d154';
  return '#2ecc8f';
}

export function gauge(score) {
  const c = heatColor(score), r = 52, circ = Math.PI * r;
  return `<svg viewBox="0 0 140 84" style="width:180px;height:108px">
    <path d="M 18 72 A ${r} ${r} 0 0 1 122 72" fill="none" stroke="#1b2536" stroke-width="13" stroke-linecap="round"/>
    <path d="M 18 72 A ${r} ${r} 0 0 1 122 72" fill="none" stroke="${c}" stroke-width="13" stroke-linecap="round"
      stroke-dasharray="${(score / 100) * circ} ${circ}"/>
    <text x="70" y="64" text-anchor="middle" font-size="26" fill="#e6edf6" font-weight="650">${score}</text>
    <text x="70" y="79" text-anchor="middle" font-size="8" fill="#63748f">RISK SCORE / 100</text></svg>`;
}

function emptyChart() { return `<div class="empty" style="padding:26px"><div class="dim">No data to chart yet.</div></div>`; }
function shorten(s, n) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }
export { esc, PALETTE };
