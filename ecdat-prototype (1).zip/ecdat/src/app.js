import { runPipeline } from './services/pipeline.js';
import { DEMO_FILES, DEMO_META } from './data/demoDataset.js';
import { mosca, WEIGHTS, levelFor } from './services/quantumRiskEngine.js';
import { PRIORITY_WEIGHTS } from './services/migrationPriorityEngine.js';
import { cbomToCSV } from './services/cbomGenerator.js';
import { label } from './services/pqcRecommendationEngine.js';
import { summarise, groupRisk, roadmap, inventoryCSV, executiveReport, technicalReport } from './services/reportGenerator.js';
import { languageOf } from './services/discoveryEngine.js';
import { SCANNABLE_EXT } from './services/cryptoRules.js';
import { barChart, donut, stackedRows, heatmap, heatColor, gauge, esc, RISK_COLOR } from './ui/charts.js';
import { readZip, zipSupported } from './ui/zip.js';

/* ============================ state ============================ */
const KEY = 'ecdat.state.v1';
const state = {
  authed: false,
  result: null,
  assumptions: { migrationYears: 4, dataLifetimeYears: 10, threatHorizonYears: 12 },
  inv: { q: '', risk: '', algo: '', app: '', env: '', lib: '', sort: 'priorityScore', dir: -1, page: 1, size: 12 },
  cbomQ: '', selected: null, drawerTab: 'overview', busy: null, toast: null
};

function persist() {
  try {
    localStorage.setItem(KEY, JSON.stringify({
      authed: state.authed, assumptions: state.assumptions,
      result: state.result ? { meta: state.result.meta, artefacts: state.result.artefacts, libraries: state.result.libraries, cbom: state.result.cbom, stats: state.result.stats } : null
    }));
  } catch (e) { /* storage full or disabled — app still works in-session */ }
}
function restore() {
  try {
    const raw = localStorage.getItem(KEY); if (!raw) return;
    const s = JSON.parse(raw);
    state.authed = !!s.authed;
    if (s.assumptions) state.assumptions = s.assumptions;
    if (s.result) state.result = s.result;
  } catch (e) { localStorage.removeItem(KEY); }
}

/* ============================ router ============================ */
const PAGES = {
  dashboard: { title: 'Dashboard', sub: 'Cryptographic posture overview', ic: '▣' },
  discovery: { title: 'Discovery', sub: 'Scan source code for cryptographic artefacts', ic: '⌕' },
  inventory: { title: 'Cryptographic Inventory', sub: 'Every discovered artefact', ic: '☰' },
  cbom: { title: 'CBOM', sub: 'Cryptography Bill of Materials', ic: '⧉' },
  risk: { title: 'Risk Analysis', sub: 'Quantum risk and Mosca-style assessment', ic: '◈' },
  apps: { title: 'Application Explorer', sub: 'Risk by application and dependency map', ic: '⬡' },
  priorities: { title: 'Migration Priorities', sub: 'Weighted prioritisation of remediation work', ic: '⇅' },
  roadmap: { title: 'Migration Roadmap', sub: 'Seven-phase programme view', ic: '⟶' },
  reports: { title: 'Reports', sub: 'Executive and technical exports', ic: '⎙' },
  methodology: { title: 'Settings & Methodology', sub: 'Scoring model and assumptions', ic: '⚙' }
};
const NAV = [
  ['Overview', ['dashboard']],
  ['Analyse', ['discovery', 'inventory', 'cbom', 'risk', 'apps']],
  ['Act', ['priorities', 'roadmap', 'reports']],
  ['Configure', ['methodology']]
];
function route() { const h = location.hash.replace(/^#\/?/, '') || 'dashboard'; return PAGES[h] ? h : 'dashboard'; }
window.addEventListener('hashchange', render);

/* ============================ helpers ============================ */
const $ = sel => document.querySelector(sel);
const uniq = (arr) => [...new Set(arr)].filter(Boolean).sort();
function artefacts() { return state.result?.artefacts || []; }
function moscaNow() { return mosca(state.assumptions); }
function toast(msg, kind = 'ok') { state.toast = { msg, kind }; render(); setTimeout(() => { state.toast = null; render(); }, 3200); }

function download(name, text, type = 'text/plain') {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click();
  a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1500);
  toast(`Downloaded ${name}`);
}

function riskPill(l) { return `<span class="pill ${l}">${l}</span>`; }

/* ============================ pipeline actions ============================ */
async function loadDemo() {
  state.busy = 'Running discovery over the built-in demo repositories…'; render();
  await new Promise(r => setTimeout(r, 120));
  state.result = runPipeline(DEMO_FILES, DEMO_META);
  state.busy = null; state.inv.page = 1; persist();
  location.hash = '#/dashboard';
  toast(`Discovery complete — ${state.result.artefacts.length} artefacts from ${state.result.stats.filesScanned} files.`);
  render();
}

async function scanFiles(fileList, meta) {
  const files = [];
  const skipped = [];
  for (const f of fileList) {
    const ext = (f.name.split('.').pop() || '').toLowerCase();
    if (f.name.toLowerCase().endsWith('.zip')) {
      if (!zipSupported()) { skipped.push(f.name + ' (ZIP unsupported in this browser)'); continue; }
      try {
        const entries = await readZip(await f.arrayBuffer());
        entries.forEach(e => {
          const x = (e.path.split('.').pop() || '').toLowerCase();
          if (SCANNABLE_EXT.includes(x)) files.push({ ...meta, path: e.path, content: e.content });
          else skipped.push(e.path);
        });
      } catch (err) { skipped.push(`${f.name} (${err.message})`); }
      continue;
    }
    if (!SCANNABLE_EXT.includes(ext)) { skipped.push(f.name); continue; }
    if (f.size > 3_000_000) { skipped.push(f.name + ' (over 3 MB)'); continue; }
    files.push({ ...meta, path: f.webkitRelativePath || f.name, content: await f.text() });
  }
  if (!files.length) {
    state.busy = null;
    toast('No scannable files found. Supported extensions: ' + SCANNABLE_EXT.join(', '), 'warn');
    render(); return;
  }
  state.result = runPipeline(files, { source: `Local upload (${files.length} file(s))`, demo: false });
  state.result.skipped = skipped;
  state.busy = null; state.inv.page = 1; persist();
  location.hash = '#/dashboard';
  toast(`Discovery complete — ${state.result.artefacts.length} artefacts from ${files.length} file(s).`);
  render();
}

function scanPasted(text, path, meta) {
  if (!text.trim()) { toast('Paste some code first.', 'warn'); return; }
  state.result = runPipeline([{ ...meta, path: path || 'pasted-snippet.py', content: text }], { source: 'Pasted snippet', demo: false });
  state.inv.page = 1; persist(); location.hash = '#/dashboard';
  toast(`Discovery complete — ${state.result.artefacts.length} artefacts.`); render();
}

function clearAll() {
  state.result = null; state.selected = null; persist(); location.hash = '#/discovery';
  toast('Workspace cleared.'); render();
}

/* ============================ views ============================ */
function loginView() {
  return `<div class="login"><div class="box">
    <div class="brand-mark" style="width:52px;height:52px;margin:0 auto 16px;font-size:17px">EC</div>
    <h1 style="margin:0 0 4px;font-size:24px;letter-spacing:-.4px">ECDAT</h1>
    <div class="dim" style="font-size:12.5px;letter-spacing:1.3px;text-transform:uppercase;margin-bottom:8px">Enterprise Cryptographic Discovery &amp; Analysis Tool</div>
    <p class="muted" style="font-size:13px;margin:0 0 20px">Prototype demonstrating automated cryptographic discovery, inventory, quantum-risk assessment and migration prioritisation.</p>
    <div class="card" style="text-align:left">
      <div class="banner info" style="margin-bottom:14px">⚠ Prototype build — this screen is a simulated sign-in. No authentication, account or server is involved, and no credentials are collected or stored.</div>
      <div class="field"><label class="fld">Analyst identity (local label only)</label><input type="text" id="who" placeholder="e.g. security.architect" value="security.architect"></div>
      <button class="btn primary" style="width:100%" data-act="enter">Enter workspace</button>
    </div>
    <div class="banner ok" style="margin-top:14px;text-align:left">🔒 All analysis runs entirely in your browser. Uploaded source code is never transmitted to any server or third-party API.</div>
    <div class="footnote">DISCOVER → INVENTORY → CBOM → QUANTUM RISK → PRIORITISE → MIGRATE</div>
  </div></div>`;
}

function shell(page) {
  const a = artefacts();
  const counts = { inventory: a.length, priorities: a.filter(x => x.priorityScore >= 70).length, cbom: state.result?.cbom.components.length || 0, apps: new Set(a.map(x => x.application)).size };
  return `<div class="shell">
    <aside class="sidebar">
      <div class="brand"><div class="brand-mark">EC</div><div><div class="brand-name">ECDAT</div><div class="brand-sub">Prototype 0.9</div></div></div>
      <nav class="nav">${NAV.map(([g, keys]) => `<div class="nav-group">${g}</div>` + keys.map(k =>
        `<a href="#/${k}" class="${page === k ? 'active' : ''}"><span class="ic">${PAGES[k].ic}</span>${PAGES[k].title}${counts[k] ? `<span class="cnt">${counts[k]}</span>` : ''}</a>`).join('')).join('')}</nav>
      <div style="margin-top:auto;padding:14px 8px 0">
        ${state.result ? `<div class="tag" style="display:block;text-align:center;margin-bottom:8px">${state.result.meta.demo ? 'DEMO DATA' : 'LOCAL SCAN'}</div>` : ''}
        <div class="footnote" style="margin:0">Local-only processing. No code leaves this browser.</div>
      </div>
    </aside>
    <main class="main">
      <header class="topbar">
        <div><h1>${PAGES[page].title}</h1><div class="sub">${PAGES[page].sub}</div></div>
        <div class="spacer"></div>
        ${state.result ? `<span class="tag mono">${state.result.artefacts.length} artefacts · ${state.result.stats.filesScanned} files · ${state.result.stats.linesScanned} lines</span>` : ''}
        <button class="btn" data-act="demo">${state.result ? 'Reload demo' : 'Load Enterprise Demo'}</button>
        ${state.result ? `<button class="btn ghost" data-act="clear">Clear</button>` : ''}
      </header>
      <div class="content">
        ${state.busy ? `<div class="banner info" style="margin-bottom:14px"><span class="spin"></span> ${esc(state.busy)}</div>` : ''}
        ${state.toast ? `<div class="banner ${state.toast.kind === 'warn' ? '' : 'ok'}" style="margin-bottom:14px">${esc(state.toast.msg)}</div>` : ''}
        ${state.result?.meta.demo ? `<div class="banner" style="margin-bottom:14px">⚠ <b>Fictional demo dataset.</b> The repositories, applications and configurations below are invented for demonstration. All figures are computed live from that sample code.</div>` : ''}
        ${pageBody(page)}
      </div>
    </main>
  </div>${state.selected ? drawer() : ''}`;
}

function needData(what) {
  return `<div class="card"><div class="empty">
    <div class="big">⌕</div>
    <div style="font-size:15px;color:var(--txt);margin-bottom:6px">No scan results yet</div>
    <div style="margin-bottom:16px">${esc(what)} appears once the discovery pipeline has run.</div>
    <div class="btn-row" style="justify-content:center">
      <button class="btn primary" data-act="demo">Load Enterprise Demo</button>
      <a class="btn" href="#/discovery">Scan my own code</a>
    </div></div></div>`;
}

function pageBody(p) {
  switch (p) {
    case 'dashboard': return state.result ? dashboard() : needData('The dashboard');
    case 'discovery': return discoveryPage();
    case 'inventory': return state.result ? inventoryPage() : needData('The inventory');
    case 'cbom': return state.result ? cbomPage() : needData('The CBOM');
    case 'risk': return state.result ? riskPage() : needData('Risk analysis');
    case 'apps': return state.result ? appsPage() : needData('The application explorer');
    case 'priorities': return state.result ? prioritiesPage() : needData('Migration priorities');
    case 'roadmap': return state.result ? roadmapPage() : needData('The roadmap');
    case 'reports': return state.result ? reportsPage() : needData('Reports');
    case 'methodology': return methodologyPage();
  }
}

/* ---------- dashboard ---------- */
function dashboard() {
  const a = artefacts(), s = summarise(a), m = moscaNow();
  const algoCounts = tally(a.map(x => x.algorithm));
  const byEnv = tally(a.map(x => x.environment));
  const bands = tally(a.map(x => x.priorityBand.split(' — ')[0]));
  const legacy = [
    { label: 'Deprecated / broken', value: s.deprecated, color: RISK_COLOR.CRITICAL },
    { label: 'Classical, in use', value: a.length - s.deprecated - s.pqcReady, color: '#3d8bfd' },
    { label: 'Post-quantum', value: s.pqcReady, color: '#22d3a6' }
  ];
  const apps = groupRisk(a);
  const metric = (v, k, d, cls = '') => `<div class="metric ${cls}"><div class="v">${v}</div><div class="k">${k}</div><div class="d">${d}</div></div>`;
  return `
  <div class="grid g4" style="margin-bottom:16px">
    ${metric(s.total, 'Artefacts', `${state.result.stats.filesScanned} files scanned`)}
    ${metric(s.applications, 'Applications', `${s.libraries} crypto libraries found`)}
    ${metric(s.critical, 'Critical risk', `${s.high} high risk`, 'crit')}
    ${metric(s.quantumVulnerable, 'Quantum-vulnerable', `${Math.round(s.quantumVulnerable / (s.total || 1) * 100)}% of inventory`, 'q')}
    ${metric(s.migrationCandidates, 'Migration candidates', 'Non-PQC with elevated risk', 'high')}
    ${metric(s.pqcReady, 'PQC-ready', 'Already post-quantum', 'good')}
    ${metric(s.certificates, 'Certificate refs', 'Longest migration lead time')}
    ${metric(s.avgRisk, 'Mean risk score', `Band: ${levelFor(s.avgRisk)}`, s.avgRisk >= 75 ? 'crit' : s.avgRisk >= 55 ? 'high' : 'good')}
  </div>

  <div class="grid g2" style="margin-bottom:16px">
    <div class="card"><h3>Risk distribution</h3><div class="hint">Artefacts by computed risk band</div>
      ${donut(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map(l => ({ label: l, value: a.filter(x => x.risk.level === l).length, color: RISK_COLOR[l] })), { label: 'artefacts' })}</div>
    <div class="card"><h3>Quantum exposure</h3><div class="hint">Shor-vulnerable public-key material vs. everything else</div>
      ${donut([
        { label: 'Quantum-vulnerable', value: s.quantumVulnerable, color: '#ff4d6a' },
        { label: 'Lower quantum impact', value: s.total - s.quantumVulnerable - s.pqcReady, color: '#3d8bfd' },
        { label: 'Post-quantum', value: s.pqcReady, color: '#22d3a6' }
      ], { label: 'artefacts' })}
      <div class="footnote">Symmetric and hash primitives are not marked vulnerable — Grover gives only a quadratic speed-up. See Methodology.</div></div>
  </div>

  <div class="grid g2" style="margin-bottom:16px">
    <div class="card"><h3>Algorithm distribution</h3><div class="hint">Detected algorithm families</div>
      ${barChart(algoCounts.slice(0, 10), { height: 210 })}</div>
    <div class="card"><h3>Risk by application</h3><div class="hint">Stacked artefact counts per risk band</div>
      ${stackedRows(apps.map(r => ({ label: `${r.application} (mean ${r.avg})`, parts: ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map(l => ({ label: l, color: RISK_COLOR[l], value: a.filter(x => x.application === r.application && x.risk.level === l).length })) })))}
      <div class="legend">${['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map(l => `<span><i style="background:${RISK_COLOR[l]}"></i>${l}</span>`).join('')}</div></div>
  </div>

  <div class="grid g3" style="margin-bottom:16px">
    <div class="card"><h3>Risk by environment</h3><div class="hint">Where the artefacts live</div>${barChart(byEnv, { horizontal: true })}</div>
    <div class="card"><h3>Migration priority bands</h3><div class="hint">From the weighted priority engine</div>${barChart(bands, { horizontal: true, color: '#3d8bfd' })}</div>
    <div class="card"><h3>Algorithm lifecycle</h3><div class="hint">Legacy vs current vs post-quantum</div>${barChart(legacy, { horizontal: true })}</div>
  </div>

  <div class="grid g2">
    <div class="card"><h3>Risk heatmap — application × primitive</h3><div class="hint">Mean risk score per cell</div>
      ${heatmap(apps.map(r => r.application), uniq(a.map(x => x.primitive)), (app, prim) => {
        const set = a.filter(x => x.application === app && x.primitive === prim);
        return set.length ? Math.round(set.reduce((t, x) => t + x.risk.score, 0) / set.length) : null;
      })}</div>
    <div class="card"><h3>Mosca-style position</h3><div class="hint">Using your current assumptions</div>
      <div class="mono" style="font-size:13px;margin-bottom:8px">${esc(m.statement)}</div>
      <div class="banner ${m.actionRequired ? '' : 'ok'}">${m.actionRequired ? '⚠ ' : '✓ '}${esc(m.verdict)}</div>
      <div class="btn-row" style="margin-top:12px"><a class="btn" href="#/risk">Adjust assumptions</a><a class="btn" href="#/priorities">View priorities</a></div>
      <h3 style="margin-top:18px">Top 3 by priority</h3>
      ${a.slice(0, 3).map(x => `<div style="padding:8px 0;border-bottom:1px solid #1a2333">
        <div style="display:flex;justify-content:space-between;gap:8px"><b>#${x.priorityRank} ${esc(label(x))}</b>${riskPill(x.risk.level)}</div>
        <div class="dim" style="font-size:11.5px">${esc(x.application)} · ${esc(x.file)}:${x.line} · priority ${x.priorityScore}/100</div></div>`).join('')}
    </div>
  </div>`;
}

/* ---------- discovery ---------- */
function discoveryPage() {
  const r = state.result;
  return `<div class="grid g2" style="margin-bottom:16px">
    <div class="card">
      <h3>Scan your own source</h3>
      <div class="hint">Files are read with the browser File API and parsed in-page. Nothing is uploaded.</div>
      <div class="drop" id="drop">
        <div style="font-size:28px;opacity:.5">⇪</div>
        <div style="margin:6px 0 3px">Drop files, a folder, or a .zip here</div>
        <div class="dim" style="font-size:11.5px">${SCANNABLE_EXT.join(' · ')}</div>
        <div class="btn-row" style="justify-content:center;margin-top:12px">
          <button class="btn" data-act="pick-files">Choose files</button>
          <button class="btn" data-act="pick-folder">Choose folder</button>
        </div>
      </div>
      <input type="file" id="fileIn" multiple style="display:none">
      <input type="file" id="dirIn" webkitdirectory directory multiple style="display:none">
      <div class="grid g3" style="margin-top:14px">
        <div class="field"><label class="fld">Application name</label><input type="text" id="mApp" value="Uploaded Project"></div>
        <div class="field"><label class="fld">Environment</label><select id="mEnv"><option>Production</option><option>Staging</option><option>Development</option><option>Unspecified</option></select></div>
        <div class="field"><label class="fld">Business criticality</label><select id="mCrit"><option value="critical">Critical</option><option value="high">High</option><option value="medium" selected>Medium</option><option value="low">Low</option></select></div>
        <div class="field"><label class="fld">Data lifetime (years)</label><input type="number" id="mLife" min="0" max="50" value="5"></div>
        <div class="field"><label class="fld">Exposure</label><select id="mExp"><option value="internet-facing">Internet-facing</option><option value="partner">Partner</option><option value="internal" selected>Internal</option><option value="isolated">Isolated</option></select></div>
      </div>
      <div class="footnote">These attributes are not detectable from code; they feed the business-criticality, data-lifetime and exposure factors of the risk model.</div>
    </div>
    <div class="card">
      <h3>Or paste a snippet</h3>
      <div class="hint">Useful for a quick demonstration of the detection rules.</div>
      <div class="field"><label class="fld">File name (sets the language)</label><input type="text" id="pName" value="auth/service.py"></div>
      <textarea id="pCode" rows="11" class="mono" placeholder="from cryptography.hazmat.primitives.asymmetric import rsa
key = rsa.generate_private_key(public_exponent=65537, key_size=2048)"></textarea>
      <div class="btn-row" style="margin-top:10px">
        <button class="btn primary" data-act="scan-paste">Run discovery</button>
        <button class="btn" data-act="sample-paste">Insert sample</button>
        <button class="btn" data-act="demo">Load Enterprise Demo</button>
      </div>
      <div class="banner ok" style="margin-top:14px">🔒 Prototype privacy note: discovery, scoring and report generation all execute locally in this browser tab. No network requests are made with your data.</div>
    </div>
  </div>

  ${r ? `<div class="card">
    <h3>Last scan</h3>
    <div class="hint">${esc(r.meta.source)} · ${new Date(r.stats.scannedAt).toLocaleString()}</div>
    <div class="grid g4" style="margin-bottom:14px">
      <div class="metric"><div class="v">${r.stats.filesScanned}</div><div class="k">Files scanned</div></div>
      <div class="metric"><div class="v">${r.stats.linesScanned}</div><div class="k">Lines parsed</div></div>
      <div class="metric"><div class="v">${r.artefacts.length}</div><div class="k">Artefacts</div></div>
      <div class="metric"><div class="v">${r.libraries.length}</div><div class="k">Library references</div></div>
    </div>
    ${r.skipped?.length ? `<div class="banner" style="margin-bottom:12px">Skipped ${r.skipped.length} unsupported file(s): <span class="mono">${esc(r.skipped.slice(0, 8).join(', '))}${r.skipped.length > 8 ? ' …' : ''}</span></div>` : ''}
    <h3>Files with findings</h3>
    <div class="tablewrap"><table><thead><tr><th>File</th><th>Language</th><th>Artefacts</th><th>Max risk</th><th>Algorithms</th></tr></thead><tbody>
    ${uniq(r.artefacts.map(x => x.file)).map(f => {
      const set = r.artefacts.filter(x => x.file === f);
      const mx = Math.max(...set.map(x => x.risk.score));
      return `<tr data-open="${esc(set[0].id)}"><td class="mono">${esc(f)}</td><td>${esc(languageOf(f))}</td><td>${set.length}</td>
        <td>${mx} ${riskPill(levelFor(mx))}</td><td class="dim">${esc(uniq(set.map(x => x.algorithm)).join(', '))}</td></tr>`;
    }).join('')}</tbody></table></div></div>` : ''}`;
}

/* ---------- inventory ---------- */
function filtered() {
  const f = state.inv;
  let a = artefacts().filter(x => {
    if (f.risk && x.risk.level !== f.risk) return false;
    if (f.algo && x.algorithm !== f.algo) return false;
    if (f.app && x.application !== f.app) return false;
    if (f.env && x.environment !== f.env) return false;
    if (f.lib && x.library !== f.lib) return false;
    if (f.q) {
      const hay = `${x.id} ${label(x)} ${x.algorithm} ${x.usage} ${x.application} ${x.library} ${x.file} ${x.language} ${x.matchedText}`.toLowerCase();
      if (!hay.includes(f.q.toLowerCase())) return false;
    }
    return true;
  });
  const key = f.sort;
  a = a.slice().sort((x, y) => {
    const gv = o => key === 'risk' ? o.risk.score : key === 'name' ? label(o) : o[key];
    const vx = gv(x), vy = gv(y);
    return (typeof vx === 'string' ? vx.localeCompare(vy) : vx - vy) * f.dir;
  });
  return a;
}

function inventoryPage() {
  const a = artefacts(), f = state.inv, rows = filtered();
  const pages = Math.max(1, Math.ceil(rows.length / f.size));
  if (f.page > pages) f.page = pages;
  const view = rows.slice((f.page - 1) * f.size, f.page * f.size);
  const sel = (id, opts, val) => `<select data-f="${id}"><option value="">All</option>${opts.map(o => `<option ${o === val ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
  return `<div class="card">
    <div class="toolbar">
      <div class="field" style="flex:1;min-width:210px"><label class="fld">Search</label><input type="text" data-f="q" value="${esc(f.q)}" placeholder="algorithm, file, library, usage…"></div>
      <div class="field"><label class="fld">Risk</label>${sel('risk', ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'], f.risk)}</div>
      <div class="field"><label class="fld">Algorithm</label>${sel('algo', uniq(a.map(x => x.algorithm)), f.algo)}</div>
      <div class="field"><label class="fld">Application</label>${sel('app', uniq(a.map(x => x.application)), f.app)}</div>
      <div class="field"><label class="fld">Environment</label>${sel('env', uniq(a.map(x => x.environment)), f.env)}</div>
      <div class="field"><label class="fld">Library</label>${sel('lib', uniq(a.map(x => x.library)), f.lib)}</div>
      <button class="btn" data-act="reset-filters">Reset</button>
      <button class="btn" data-act="export-inv-csv">Export CSV</button>
      <button class="btn" data-act="export-inv-json">Export JSON</button>
    </div>
    <div class="hint">${rows.length} of ${a.length} artefacts match. Click any row for the full analysis, detection evidence and source context.</div>
    ${rows.length ? `<div class="tablewrap"><table><thead><tr>
      ${[['id', 'ID'], ['name', 'Algorithm'], ['keySize', 'Key size'], ['usage', 'Usage'], ['application', 'Application'], ['library', 'Library'], ['file', 'Location'], ['risk', 'Quantum risk'], ['priorityScore', 'Priority']].map(([k, t]) =>
        `<th data-sort="${k}">${t}${f.sort === k ? (f.dir === 1 ? ' ▲' : ' ▼') : ''}</th>`).join('')}
      <th style="cursor:default">Recommended action</th></tr></thead><tbody>
      ${view.map(x => `<tr data-open="${x.id}">
        <td class="mono">${x.id}</td>
        <td><b>${esc(label(x))}</b>${x.pqc ? ' <span class="pill PQC">PQC</span>' : ''}</td>
        <td class="mono">${x.keySize ?? '–'}</td>
        <td>${esc(x.usage)}</td>
        <td>${esc(x.application)}<div class="dim" style="font-size:11px">${esc(x.environment)}</div></td>
        <td class="dim">${esc(x.library)}</td>
        <td class="mono" style="font-size:11.5px">${esc(shorten(x.file, 30))}:${x.line}</td>
        <td>${x.risk.score} ${riskPill(x.risk.level)}</td>
        <td>${x.priorityScore}<div class="bar" style="margin-top:4px"><i style="width:${x.priorityScore}%;background:${heatColor(x.priorityScore)}"></i></div></td>
        <td class="dim" style="font-size:11.5px;max-width:280px">${esc(shorten(x.recommendation.action, 110))}</td>
      </tr>`).join('')}
    </tbody></table></div>
    <div class="pager">
      <span>Page ${f.page} of ${pages}</span>
      <button class="btn" data-act="prev" ${f.page === 1 ? 'disabled' : ''}>Previous</button>
      <button class="btn" data-act="next" ${f.page === pages ? 'disabled' : ''}>Next</button>
      <select data-f="size" style="width:auto">${[12, 25, 50].map(n => `<option ${n === f.size ? 'selected' : ''}>${n}</option>`).join('')}</select>
    </div>` : `<div class="empty"><div class="big">⌕</div>No artefacts match these filters.<div style="margin-top:12px"><button class="btn" data-act="reset-filters">Reset filters</button></div></div>`}
  </div>`;
}

/* ---------- CBOM ---------- */
function cbomPage() {
  const cb = state.result.cbom;
  const q = state.cbomQ.toLowerCase();
  const comps = cb.components.filter(c => !q || JSON.stringify(c).toLowerCase().includes(q));
  return `<div class="grid" style="gap:16px">
    <div class="card">
      <h3>Cryptography Bill of Materials</h3>
      <div class="hint">${cb.components.length} cryptographic components · generated ${new Date(cb.metadata.timestamp).toLocaleString()}</div>
      <div class="banner info" style="margin-bottom:12px">Structure is <b>inspired by</b> CycloneDX cryptographic-asset concepts. This prototype does not validate against the CycloneDX schema and makes no compliance claim.</div>
      <div class="toolbar">
        <div class="field" style="flex:1"><label class="fld">Search CBOM</label><input type="text" data-f="cbomQ" value="${esc(state.cbomQ)}" placeholder="algorithm, library, application, file…"></div>
        <button class="btn primary" data-act="cbom-json">Download JSON</button>
        <button class="btn" data-act="cbom-csv">Download CSV</button>
        <button class="btn" data-act="cbom-readable">Human-readable report</button>
      </div>
      <div class="hint">${comps.length} component(s) shown</div>
      ${comps.length ? `<div class="tablewrap"><table><thead><tr><th style="cursor:default">bom-ref</th><th style="cursor:default">Component</th><th style="cursor:default">Asset type</th><th style="cursor:default">Key size</th><th style="cursor:default">Protocol</th><th style="cursor:default">Library</th><th style="cursor:default">Location</th><th style="cursor:default">Dependencies</th><th style="cursor:default">Risk</th><th style="cursor:default">Recommendation</th></tr></thead><tbody>
        ${comps.slice(0, 200).map(c => `<tr data-open="${c['bom-ref']}">
          <td class="mono">${c['bom-ref']}</td><td><b>${esc(c.name)}</b></td><td>${esc(c.cryptoProperties.assetType)}</td>
          <td class="mono">${c.cryptoProperties.keySize ?? '–'}</td><td class="dim">${esc(c.protocol || '–')}</td>
          <td class="dim">${esc(c.library.name)}${c.library.version ? ' ' + esc(c.library.version) : ''}</td>
          <td class="mono" style="font-size:11.5px">${esc(shorten(c.occurrence.file, 26))}:${c.occurrence.line}</td>
          <td class="dim">${c.dependencies.length}</td>
          <td>${c.risk.score} ${riskPill(c.risk.level)}</td>
          <td class="dim" style="font-size:11.5px;max-width:260px">${esc(shorten(c.recommendation.target || c.recommendation.action, 90))}</td></tr>`).join('')}
      </tbody></table></div>${comps.length > 200 ? `<div class="footnote">Showing the first 200 components; export for the full set.</div>` : ''}`
      : `<div class="empty">No components match that search.</div>`}
    </div>
    <div class="card"><h3>Library inventory</h3><div class="hint">Cryptographic libraries referenced per application</div>
      ${cb.libraries.length ? `<div class="tablewrap"><table style="min-width:auto"><thead><tr><th style="cursor:default">Application</th><th style="cursor:default">Library</th><th style="cursor:default">Version</th></tr></thead><tbody>
      ${cb.libraries.map(l => `<tr style="cursor:default"><td>${esc(l.application)}</td><td>${esc(l.name)}</td><td class="mono">${esc(l.version || 'not identified')}</td></tr>`).join('')}
      </tbody></table></div>` : `<div class="empty">No library references detected.</div>`}
    </div>
  </div>`;
}

/* ---------- risk ---------- */
function riskPage() {
  const a = artefacts(), m = moscaNow(), s = summarise(a);
  const span = 20, scale = v => Math.min(100, (v / span) * 100);
  return `<div class="grid g2" style="margin-bottom:16px">
    <div class="card">
      <h3>Mosca-style migration decision</h3>
      <div class="hint">If (data lifetime + migration time) exceeds the assumed threat horizon, planning must start now.</div>
      <div class="grid g3">
        <div class="field"><label class="fld">Migration time (years)</label><input type="number" data-a="migrationYears" min="0" max="30" step="0.5" value="${state.assumptions.migrationYears}"></div>
        <div class="field"><label class="fld">Data security lifetime (years)</label><input type="number" data-a="dataLifetimeYears" min="0" max="50" step="0.5" value="${state.assumptions.dataLifetimeYears}"></div>
        <div class="field"><label class="fld">Quantum threat horizon (years)</label><input type="number" data-a="threatHorizonYears" min="1" max="50" step="0.5" value="${state.assumptions.threatHorizonYears}"></div>
      </div>
      <div style="margin:14px 0 8px">
        <div style="font-size:11.5px;color:var(--muted);margin-bottom:4px">Data lifetime + migration time = ${m.total} years</div>
        <div style="display:flex;height:16px;border-radius:5px;overflow:hidden;background:#1b2536">
          <span style="width:${scale(m.dataLifetimeYears)}%;background:#3d8bfd" title="Data lifetime"></span>
          <span style="width:${scale(m.migrationYears)}%;background:#7b5bf0" title="Migration time"></span>
        </div>
        <div style="font-size:11.5px;color:var(--muted);margin:10px 0 4px">Assumed quantum threat horizon = ${m.threatHorizonYears} years</div>
        <div style="display:flex;height:16px;border-radius:5px;overflow:hidden;background:#1b2536">
          <span style="width:${scale(m.threatHorizonYears)}%;background:${m.actionRequired ? '#ff4d6a' : '#2ecc8f'}"></span>
        </div>
        <div class="legend"><span><i style="background:#3d8bfd"></i>Data lifetime</span><span><i style="background:#7b5bf0"></i>Migration time</span><span><i style="background:${m.actionRequired ? '#ff4d6a' : '#2ecc8f'}"></i>Threat horizon</span><span class="dim">axis: 0–${span} years</span></div>
      </div>
      <div class="mono" style="font-size:13px;margin-bottom:8px">${esc(m.statement)}</div>
      <div class="banner ${m.actionRequired ? '' : 'ok'}">${m.actionRequired ? '⚠ Migration planning required. ' : '✓ '}${esc(m.verdict)}</div>
      <div class="footnote">ECDAT does not predict when a cryptographically relevant quantum computer will exist. The horizon above is <b>your</b> planning assumption and is applied consistently across every calculation.</div>
    </div>
    <div class="card">
      <h3>Programme risk profile</h3>
      <div class="hint">Mean risk across the whole inventory</div>
      <div style="display:flex;justify-content:center">${gauge(s.avgRisk)}</div>
      <div class="kv" style="margin-top:8px">
        <dt>Artefacts above 75</dt><dd>${a.filter(x => x.risk.score >= 75).length} (critical)</dd>
        <dt>Quantum-vulnerable</dt><dd>${s.quantumVulnerable}</dd>
        <dt>Deprecated primitives</dt><dd>${s.deprecated} — fix regardless of quantum timeline</dd>
        <dt>Post-quantum already</dt><dd>${s.pqcReady}</dd>
      </div>
      <h3 style="margin-top:16px">Mean factor contribution</h3>
      <div class="hint">Average points per factor across all artefacts (max in brackets)</div>
      ${barChart(Object.keys(WEIGHTS).map((k, i) => {
        const name = k.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase());
        const key = ['Quantum vulnerability', 'Algorithm strength', 'Business criticality', 'Data lifetime', 'Exposure', 'Migration complexity'][i];
        const avg = a.length ? a.reduce((t, x) => t + (x.risk.factors.find(f => f.key === key)?.points || 0), 0) / a.length : 0;
        return { label: `${key} (${WEIGHTS[k]})`, value: Math.round(avg * 10) / 10 };
      }), { horizontal: true })}
    </div>
  </div>
  <div class="card"><h3>Risk by algorithm family</h3><div class="hint">Mean computed risk — note that symmetric and hash primitives score lower by design</div>
    ${barChart(uniq(a.map(x => x.algorithm)).map(alg => {
      const set = a.filter(x => x.algorithm === alg);
      const v = Math.round(set.reduce((t, x) => t + x.risk.score, 0) / set.length);
      return { label: `${alg} ×${set.length}`, value: v, color: heatColor(v) };
    }).sort((x, y) => y.value - x.value), { horizontal: true })}</div>`;
}

/* ---------- applications ---------- */
function appsPage() {
  const a = artefacts(), groups = groupRisk(a);
  return groups.map(g => {
    const set = a.filter(x => x.application === g.application);
    const meta = set[0];
    return `<div class="card" style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start">
        <div><h3 style="font-size:15px">${esc(g.application)}</h3>
          <div class="hint">${esc(meta.environment)} · criticality ${esc(meta.criticality)} · exposure ${esc(meta.exposure)} · data lifetime ${meta.dataLifetimeYears}y</div></div>
        <div style="text-align:right"><div style="font-size:22px;font-weight:650;color:${heatColor(g.avg)}">${g.avg}</div><div class="dim" style="font-size:11px">MEAN RISK</div></div>
      </div>
      <div class="grid g3" style="margin:10px 0 12px">
        <div><div class="dim" style="font-size:11px;text-transform:uppercase;letter-spacing:.6px">Artefacts</div><b>${g.count}</b> · ${g.critical} critical · ${g.high} high</div>
        <div><div class="dim" style="font-size:11px;text-transform:uppercase;letter-spacing:.6px">Quantum-vulnerable</div><b>${g.quantumVulnerable}</b> of ${g.count}</div>
        <div><div class="dim" style="font-size:11px;text-transform:uppercase;letter-spacing:.6px">Top priority rank</div><b>#${Math.min(...set.map(x => x.priorityRank))}</b></div>
      </div>
      <div class="grid g3">
        <div><div class="fld">Algorithms</div>${uniq(set.map(x => label(x))).map(t => `<span class="tag" style="margin:0 4px 4px 0">${esc(t)}</span>`).join('')}</div>
        <div><div class="fld">Libraries</div>${uniq(set.map(x => x.library)).map(t => `<span class="tag" style="margin:0 4px 4px 0">${esc(t)}</span>`).join('')}
          <div class="fld" style="margin-top:8px">Protocols &amp; certificates</div>
          ${uniq([...set.filter(x => x.protocol).map(x => x.protocol), ...set.filter(x => x.primitive === 'certificate').map(() => 'X.509 certificate reference')]).map(t => `<span class="tag" style="margin:0 4px 4px 0">${esc(t)}</span>`).join('') || '<span class="dim">none detected</span>'}</div>
        <div><div class="fld">Depends on</div>${(meta.dependencies || []).map(d => `<span class="tag" style="margin:0 4px 4px 0">⬡ ${esc(d)}</span>`).join('') || '<span class="dim">no recorded dependencies</span>'}
          <div class="fld" style="margin-top:8px">Depended on by</div>
          ${uniq(a.filter(x => (x.dependencies || []).includes(g.application)).map(x => x.application)).map(d => `<span class="tag" style="margin:0 4px 4px 0">⬡ ${esc(d)}</span>`).join('') || '<span class="dim">none recorded</span>'}</div>
      </div>
      <div class="fld" style="margin-top:12px">Leading migration recommendations</div>
      ${uniq(set.slice(0, 40).map(x => x.recommendation.action)).slice(0, 3).map(t => `<div class="dim" style="font-size:12px;margin-bottom:4px">→ ${esc(t)}</div>`).join('')}
      <div class="btn-row" style="margin-top:10px"><button class="btn" data-act="filter-app" data-val="${esc(g.application)}">Open in inventory</button></div>
    </div>`;
  }).join('');
}

/* ---------- priorities ---------- */
function prioritiesPage() {
  const a = artefacts();
  return `<div class="card" style="margin-bottom:14px">
    <h3>How priority is calculated</h3>
    <div class="hint">priority = ${Object.entries(PRIORITY_WEIGHTS).map(([k, v]) => `${v}·${k}`).join(' + ')} — each term normalised to 0–100.</div>
    <div class="banner info">Migration complexity is deliberately excluded from the priority score. Complex work is <b>slower</b>, not less urgent; it is reported separately so it can be started earlier.</div>
  </div>
  ${a.slice(0, 25).map(x => `<div class="card" style="margin-bottom:10px;cursor:pointer" data-open="${x.id}">
    <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
      <div style="width:52px;flex:none;text-align:center">
        <div style="font-size:19px;font-weight:660;color:${heatColor(x.priorityScore)}">#${x.priorityRank}</div>
        <div class="dim" style="font-size:10px">${esc(x.priorityBand.split(' — ')[0])}</div></div>
      <div style="flex:1;min-width:240px">
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <b style="font-size:14.5px">${esc(label(x))}</b>${riskPill(x.risk.level)}
          <span class="tag">${esc(x.application)}</span><span class="tag">${esc(x.environment)}</span>${x.pqc ? '<span class="pill PQC">PQC</span>' : ''}</div>
        <div class="dim mono" style="font-size:11.5px;margin:3px 0 7px">${esc(x.file)}:${x.line} · ${esc(x.usage)} · ${esc(x.library)}</div>
        <div style="font-size:12.5px">→ ${esc(x.recommendation.action)}</div>
        ${x.recommendation.transition ? `<div class="dim" style="font-size:12px;margin-top:3px">Transition: <span class="mono">${esc(x.recommendation.transition)}</span> → target <span class="mono">${esc(x.recommendation.target)}</span></div>` : ''}
      </div>
      <div style="width:210px;flex:none">
        <div style="display:flex;justify-content:space-between;font-size:11px" class="dim"><span>PRIORITY</span><span class="mono">${x.priorityScore}/100</span></div>
        <div class="bar" style="margin:4px 0 8px"><i style="width:${x.priorityScore}%;background:${heatColor(x.priorityScore)}"></i></div>
        ${Object.entries(x.priorityParts).map(([k, v]) => `<div style="display:flex;justify-content:space-between;font-size:10.5px;color:var(--dim)"><span>${esc(k)}</span><span class="mono">${Math.round(v)}×${PRIORITY_WEIGHTS[k]}</span></div>`).join('')}
      </div>
    </div></div>`).join('')}
    ${a.length > 25 ? `<div class="footnote">Showing the top 25 of ${a.length}. The full ranking is in the inventory and the technical report.</div>` : ''}`;
}

/* ---------- roadmap ---------- */
function roadmapPage() {
  const a = artefacts(), phases = roadmap(a), s = summarise(a);
  const nextIdx = phases.findIndex(p => p.status === 'Recommended next');
  return `<div class="grid g2">
    <div class="card"><h3>Seven-phase migration programme</h3>
      <div class="hint">Status is derived from the current scan, not fixed text.</div>
      ${phases.map((p, i) => `<div class="phase ${p.status === 'Complete' ? 'done' : i === nextIdx ? 'next' : ''}">
        <div class="num">${p.phase}</div>
        <div><div style="display:flex;gap:8px;align-items:center"><b>${p.name}</b><span class="tag">${esc(p.status)}</span></div>
        <div class="dim" style="font-size:12px">${esc(p.detail)}</div></div></div>`).join('')}
    </div>
    <div class="card"><h3>Suggested sequencing from this scan</h3>
      <div class="hint">Derived from the discovered artefacts and their priority bands</div>
      ${[
        ['Immediate (0–3 months)', a.filter(x => ['MD5', 'SHA-1', 'DES', '3DES', 'RC4', 'SSL'].includes(x.algorithm)), 'Remove classically broken primitives. This is a defect backlog, independent of quantum risk.'],
        ['Near term (3–12 months)', a.filter(x => x.priorityScore >= 70 && !['MD5', 'SHA-1', 'DES', '3DES', 'RC4', 'SSL'].includes(x.algorithm)), 'Enable hybrid key establishment at the highest-exposure terminators and begin certificate-lifecycle work.'],
        ['Medium term (1–2 years)', a.filter(x => x.priorityScore >= 55 && x.priorityScore < 70), 'Pilot ML-DSA signatures and measure size/performance impact before wider rollout.'],
        ['Ongoing', a.filter(x => x.priorityScore < 55), 'Scheduled upgrades and continuous re-discovery in CI.']
      ].map(([t, set, note]) => `<div style="padding:11px 0;border-bottom:1px solid #1a2333">
        <div style="display:flex;justify-content:space-between"><b>${t}</b><span class="mono dim">${set.length} artefact(s)</span></div>
        <div class="dim" style="font-size:12px;margin:3px 0 6px">${note}</div>
        ${uniq(set.map(x => label(x))).slice(0, 8).map(l => `<span class="tag" style="margin:0 4px 4px 0">${esc(l)}</span>`).join('') || '<span class="dim" style="font-size:12px">nothing in this bucket</span>'}
      </div>`).join('')}
      <div class="footnote">${s.migrationCandidates} migration candidate(s) in total. Sequencing is advisory: confirm each use case before changing production cryptography.</div>
    </div></div>`;
}

/* ---------- reports ---------- */
function reportsPage() {
  const a = artefacts(), m = moscaNow();
  const ex = executiveReport(a, m, state.result.meta);
  return `<div class="grid g2" style="margin-bottom:16px">
    <div class="card"><h3>Executive report</h3><div class="hint">Posture, quantum exposure, top migration areas and next steps</div>
      <div class="btn-row"><button class="btn primary" data-act="rep-exec">Download .txt</button><button class="btn" data-act="rep-exec-print">Open printable / save as PDF</button></div>
      <div class="code" style="margin-top:12px;max-height:340px;padding:12px;white-space:pre-wrap">${esc(ex.slice(0, 2600))}${ex.length > 2600 ? '\n…' : ''}</div></div>
    <div class="card"><h3>Technical report</h3><div class="hint">Full inventory, every risk derivation, detection evidence and roadmap</div>
      <div class="btn-row"><button class="btn primary" data-act="rep-tech">Download .txt</button><button class="btn" data-act="rep-tech-print">Open printable / save as PDF</button></div>
      <h3 style="margin-top:16px">Structured exports</h3>
      <div class="btn-row"><button class="btn" data-act="cbom-json">CBOM (JSON)</button><button class="btn" data-act="cbom-csv">CBOM (CSV)</button>
        <button class="btn" data-act="export-inv-csv">Inventory (CSV)</button><button class="btn" data-act="export-inv-json">Full analysis (JSON)</button></div>
      <div class="footnote">PDF export uses the browser print dialogue ("Save as PDF"), which keeps the prototype dependency-free and fully offline.</div></div>
  </div>
  <div class="card"><h3>What is in each export</h3>
    <div class="tablewrap"><table style="min-width:auto"><thead><tr><th style="cursor:default">Export</th><th style="cursor:default">Format</th><th style="cursor:default">Contents</th></tr></thead><tbody>
    ${[['Executive report', 'TXT / print→PDF', 'Posture summary, Mosca assessment, top 5 priorities, risk by application, next steps'],
       ['Technical report', 'TXT / print→PDF', 'Methodology, per-artefact factor breakdown, detection evidence, roadmap, limitations'],
       ['CBOM', 'JSON', 'Full component list with crypto properties, occurrences, dependencies, risk and recommendations'],
       ['CBOM', 'CSV', 'Flattened component table for spreadsheets and GRC tooling'],
       ['Inventory', 'CSV', 'One row per artefact with risk, priority and recommended action'],
       ['Full analysis', 'JSON', 'Artefacts, risk factors, recommendations, priority parts and scan metadata']]
      .map(r => `<tr style="cursor:default"><td><b>${r[0]}</b></td><td class="mono">${r[1]}</td><td class="dim">${r[2]}</td></tr>`).join('')}
    </tbody></table></div></div>`;
}

/* ---------- methodology ---------- */
function methodologyPage() {
  const rows = [
    ['Quantum vulnerability', WEIGHTS.quantumVulnerability, 'Per-algorithm normalised value. Shor-breakable public-key schemes (RSA, DH, ECDSA, ECDH) sit at 1.0. Symmetric ciphers and hashes sit far lower because Grover offers only a quadratic speed-up. AES-256 scores below AES-128; SHA-384/512 below SHA-224.'],
    ['Algorithm strength', WEIGHTS.algorithmStrength, 'Classical parameter health: key length, curve size, mode of operation, and whether the primitive is already broken (MD5, SHA-1, DES, RC4, SSL).'],
    ['Business criticality', WEIGHTS.businessCriticality, 'Supplied metadata: critical 1.0, high 0.75, medium 0.5, low 0.25.'],
    ['Data lifetime', WEIGHTS.dataLifetime, 'min(1, years / 15). Long-lived confidentiality increases harvest-now-decrypt-later exposure.'],
    ['Exposure', WEIGHTS.exposure, 'internet-facing 1.0, partner 0.7, internal 0.4, isolated 0.15.'],
    ['Migration complexity', WEIGHTS.migrationComplexity, 'Primitive type plus a dependency boost (0.06 each, capped at 0.3). Certificates and protocols are hardest to change.']
  ];
  return `<div class="grid g2" style="margin-bottom:16px">
    <div class="card"><h3>Quantum risk scoring model</h3>
      <div class="hint">score = Σ (normalised factor × weight), bounded to 0–100. Fully deterministic — the same artefact always yields the same score.</div>
      <div class="tablewrap"><table style="min-width:auto"><thead><tr><th style="cursor:default">Factor</th><th style="cursor:default">Max</th><th style="cursor:default">How it is derived</th></tr></thead><tbody>
      ${rows.map(r => `<tr style="cursor:default"><td><b>${r[0]}</b></td><td class="mono">${r[1]}</td><td class="dim" style="font-size:12px">${r[2]}</td></tr>`).join('')}
      <tr style="cursor:default"><td><b>Total</b></td><td class="mono">100</td><td class="dim">Bands: LOW &lt; 35 ≤ MEDIUM &lt; 55 ≤ HIGH &lt; 75 ≤ CRITICAL</td></tr>
      </tbody></table></div>
      <div class="banner info" style="margin-top:12px">Not every non-PQC algorithm is critical. AES-256 and SHA-384 score low here by design; the model separates <i>quantum</i> risk from <i>classical</i> defects and reports both.</div>
    </div>
    <div class="card"><h3>Migration priority model</h3>
      <div class="hint">A separate weighted blend, so that "urgent" and "hard" stay distinguishable.</div>
      ${barChart(Object.entries(PRIORITY_WEIGHTS).map(([k, v]) => ({ label: k, value: Math.round(v * 100) })), { horizontal: true })}
      <h3 style="margin-top:16px">Planning assumptions</h3>
      <div class="hint">These feed the Mosca-style assessment on every page and in every report.</div>
      <div class="grid g3">
        <div class="field"><label class="fld">Migration time (y)</label><input type="number" data-a="migrationYears" min="0" step="0.5" value="${state.assumptions.migrationYears}"></div>
        <div class="field"><label class="fld">Data lifetime (y)</label><input type="number" data-a="dataLifetimeYears" min="0" step="0.5" value="${state.assumptions.dataLifetimeYears}"></div>
        <div class="field"><label class="fld">Threat horizon (y)</label><input type="number" data-a="threatHorizonYears" min="1" step="0.5" value="${state.assumptions.threatHorizonYears}"></div>
      </div>
      <div class="btn-row"><button class="btn" data-act="reset-assumptions">Restore defaults</button>${state.result ? `<button class="btn ghost" data-act="clear">Clear workspace</button>` : ''}</div>
    </div>
  </div>
  <div class="grid g2">
    <div class="card"><h3>PQC recommendation logic</h3>
      <div class="hint">Mapping is use-case dependent, never one-size-fits-all.</div>
      <div class="tablewrap"><table style="min-width:auto"><thead><tr><th style="cursor:default">Detected</th><th style="cursor:default">Hybrid transition</th><th style="cursor:default">Target</th></tr></thead><tbody>
      ${[['ECDH / DH / RSA key transport', 'classical + ML-KEM-768', 'ML-KEM-768 (FIPS 203)'],
         ['ECDSA / RSA signatures', 'classical + ML-DSA-65', 'ML-DSA-65 (FIPS 204)'],
         ['Long-lived roots / certificates', 'composite or dual certificate', 'SLH-DSA (FIPS 205) for trust anchors'],
         ['AES-128', 'n/a', 'AES-256-GCM — no PQC algorithm required'],
         ['AES-256 / ChaCha20', 'n/a', 'retain, review key management'],
         ['MD5 / SHA-1 / DES / 3DES / RC4 / SSL', 'n/a', 'replace now — classical defect, not a quantum one'],
         ['PBKDF2', 'n/a', 'Argon2id with tuned memory cost']]
        .map(r => `<tr style="cursor:default"><td>${r[0]}</td><td class="mono dim">${r[1]}</td><td class="mono">${r[2]}</td></tr>`).join('')}
      </tbody></table></div>
      <div class="footnote">All outputs are migration <b>recommendations</b> for human review, not automatic replacements. Confirm the real use case before changing production cryptography.</div>
    </div>
    <div class="card"><h3>Prototype limitations</h3>
      <div class="hint">Stated explicitly so the scope is not overclaimed.</div>
      <ul style="margin:0;padding-left:18px;font-size:12.6px;color:var(--muted);line-height:1.8">
        <li>Detection is <b>pattern-based</b>: regular expressions over source text. No dataflow, taint or call-graph analysis, so both false positives and false negatives are expected.</li>
        <li>No binary, runtime, network, TLS-handshake or certificate-store scanning. Certificate findings are <i>references in code and configuration</i>, not parsed X.509 objects.</li>
        <li>Business criticality, data lifetime, exposure and dependencies are supplied metadata, not measured facts.</li>
        <li>The CBOM structure is inspired by CycloneDX cryptographic-asset concepts but is <b>not</b> schema-validated and claims no standards compliance.</li>
        <li>The quantum threat horizon is a user assumption. ECDAT makes no prediction about quantum timelines.</li>
        <li>No production security certification, no guaranteed compliance, no automatic safe migration.</li>
      </ul>
      <div class="banner ok" style="margin-top:12px">🔒 Data handling: every stage runs in this browser tab. Scan results and assumptions are cached in localStorage on this device only; "Clear workspace" removes them.</div>
    </div>
  </div>`;
}

/* ---------- artefact drawer ---------- */
function drawer() {
  const x = artefacts().find(a => a.id === state.selected);
  if (!x) return '';
  const tab = state.drawerTab;
  const t = (k, l) => `<button class="${tab === k ? 'on' : ''}" data-tab="${k}">${l}</button>`;
  return `<div class="drawer" data-close-drawer><div class="panel" style="position:relative">
    <button class="btn closex" data-act="close-drawer">✕</button>
    <div class="mono dim" style="font-size:11.5px">${x.id}</div>
    <h2>${esc(label(x))} ${riskPill(x.risk.level)} ${x.pqc ? '<span class="pill PQC">POST-QUANTUM</span>' : ''}</h2>
    <div class="dim mono" style="font-size:12px">${esc(x.file)}:${x.line} · ${esc(x.language)} · confidence ${x.confidence}</div>
    <div class="tabs">${t('overview', 'Analysis')}${t('explain', 'Explain risk')}${t('source', 'Source evidence')}${t('migrate', 'Migration')}</div>
    ${tab === 'overview' ? `
      <div style="display:flex;gap:18px;flex-wrap:wrap;align-items:center;margin-bottom:12px">${gauge(x.risk.score)}
        <div><div class="dim" style="font-size:11px">MIGRATION PRIORITY</div><div style="font-size:22px;font-weight:650">#${x.priorityRank} <span class="mono" style="font-size:14px;color:var(--muted)">${x.priorityScore}/100</span></div>
        <div class="tag">${esc(x.priorityBand)}</div></div></div>
      <dl class="kv">
        <dt>What was detected</dt><dd>${esc(label(x))} — ${esc(x.usage)}</dd>
        <dt>Primitive</dt><dd>${esc(x.primitive)}</dd>
        <dt>Key size / curve</dt><dd class="mono">${x.keySize ?? '–'}${x.curve ? ' · ' + esc(x.curve) : ''}${x.mode ? ' · ' + esc(x.mode) : ''}</dd>
        <dt>Library</dt><dd>${esc(x.library)}${x.libraryVersion ? ' ' + esc(x.libraryVersion) : ''}</dd>
        <dt>Protocol</dt><dd>${esc(x.protocol || '–')}</dd>
        <dt>Certificate ref</dt><dd class="mono">${esc(x.certificate || '–')}</dd>
        <dt>Application</dt><dd>${esc(x.application)} · ${esc(x.environment)}</dd>
        <dt>Business context</dt><dd>criticality ${esc(x.criticality)} · exposure ${esc(x.exposure)} · data lifetime ${x.dataLifetimeYears}y</dd>
        <dt>Dependencies</dt><dd>${(x.dependencies || []).map(d => `<span class="tag">${esc(d)}</span>`).join(' ') || '<span class="dim">none recorded</span>'}</dd>
        <dt>Quantum vulnerable</dt><dd>${x.risk.quantumVulnerable ? '<b style="color:var(--crit)">Yes</b> — Shor-breakable family' : 'Not directly — see explanation'}</dd>
        <dt>Business impact</dt><dd>${esc(impactText(x))}</dd>
      </dl>` : ''}
    ${tab === 'explain' ? `
      <div class="hint">Every point below comes from the published formula. Nothing is estimated or randomised.</div>
      ${x.risk.factors.map(f => `<div style="padding:9px 0;border-bottom:1px solid #1a2333">
        <div style="display:flex;justify-content:space-between"><b>${esc(f.key)}</b><span class="mono">+${f.points} / ${f.max}</span></div>
        <div class="bar" style="margin:5px 0 6px"><i style="width:${(f.points / f.max) * 100}%;background:${heatColor((f.points / f.max) * 100)}"></i></div>
        <div class="dim" style="font-size:12px">${esc(f.rationale)}</div></div>`).join('')}
      <div style="display:flex;justify-content:space-between;padding:12px 0;font-size:15px"><b>Total</b><b class="mono">${x.risk.score} / 100 → ${x.risk.level}</b></div>
      <div class="footnote">${esc(x.risk.formula)}</div>` : ''}
    ${tab === 'source' ? `
      <div class="hint">Why this was flagged: ${esc(x.detectionReason)}</div>
      <div class="kv" style="margin-bottom:10px"><dt>Rule</dt><dd class="mono">${esc(x.ruleId)}</dd><dt>Matched text</dt><dd class="mono">${esc(x.matchedText)}</dd><dt>Confidence</dt><dd class="mono">${x.confidence}</dd></div>
      <div class="code">${x.snippet.map(l => `<div class="ln ${l.n === x.line ? 'hit' : ''}"><span class="n">${l.n}</span><span class="t">${esc(l.text)}</span></div>`).join('')}</div>
      <div class="footnote">Confidence reflects how unambiguous the pattern is, not a guarantee of correctness. Pattern matching produces false positives — confirm before acting.</div>` : ''}
    ${tab === 'migrate' ? `
      <dl class="kv">
        <dt>Current</dt><dd class="mono">${esc(x.recommendation.current || label(x))}</dd>
        <dt>Hybrid transition</dt><dd class="mono">${esc(x.recommendation.transition || 'not applicable')}</dd>
        <dt>Future target</dt><dd class="mono">${esc(x.recommendation.target || '–')}</dd>
        <dt>PQC family</dt><dd>${esc(x.recommendation.family || '–')}</dd>
        <dt>Compatibility</dt><dd>${esc(x.recommendation.compatibility || '–')}</dd>
        <dt>Performance</dt><dd>${esc(x.recommendation.performanceNote || 'no significant impact expected')}</dd>
      </dl>
      <div class="banner info" style="margin-top:12px">${esc(x.recommendation.action)}</div>
      ${(x.recommendation.notes || []).map(n => `<div class="footnote">• ${esc(n)}</div>`).join('')}
      <div class="footnote">This is a migration <b>recommendation</b> for human review, not an automatic replacement.</div>` : ''}
  </div></div>`;
}

function impactText(x) {
  const parts = [];
  if (x.exposure === 'internet-facing') parts.push('internet-facing component');
  if (x.criticality === 'critical') parts.push('critical business system');
  if ((x.dataLifetimeYears ?? 0) >= 10) parts.push(`data must stay confidential for ~${x.dataLifetimeYears} years`);
  if (x.risk.quantumVulnerable && ['key-establishment', 'protocol'].includes(x.primitive)) parts.push('exposed to harvest-now-decrypt-later');
  if ((x.dependencies || []).length) parts.push(`${x.dependencies.length} downstream/upstream dependency link(s)`);
  return parts.length ? parts.join('; ') + '.' : 'Limited blast radius based on the recorded metadata.';
}

/* ============================ utils ============================ */
function tally(list) {
  const m = new Map();
  list.forEach(v => m.set(v, (m.get(v) || 0) + 1));
  return [...m.entries()].map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
}
function shorten(s, n) { s = String(s); return s.length > n ? '…' + s.slice(-(n - 1)) : s; }

function printable(title, body) {
  const w = window.open('', '_blank');
  if (!w) { toast('Pop-up blocked — allow pop-ups to use the printable view.', 'warn'); return; }
  w.document.write(`<!doctype html><meta charset="utf-8"><title>${title}</title>
    <style>body{font:12px/1.5 ui-monospace,Menlo,Consolas,monospace;padding:28px;color:#111;max-width:980px}
    h1{font:600 16px sans-serif} pre{white-space:pre-wrap;word-break:break-word}</style>
    <h1>${title}</h1><pre>${body.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]))}</pre>`);
  w.document.close();
  setTimeout(() => w.print(), 400);
}

/* ============================ events ============================ */
document.addEventListener('click', async (e) => {
  const closeEl = e.target.closest('[data-close-drawer]');
  if (closeEl && e.target === closeEl) { state.selected = null; render(); return; }

  const tabBtn = e.target.closest('[data-tab]');
  if (tabBtn) { state.drawerTab = tabBtn.dataset.tab; render(); return; }

  const row = e.target.closest('[data-open]');
  if (row) { state.selected = row.dataset.open; state.drawerTab = 'overview'; render(); return; }

  const th = e.target.closest('th[data-sort]');
  if (th) { const k = th.dataset.sort; if (state.inv.sort === k) state.inv.dir *= -1; else { state.inv.sort = k; state.inv.dir = -1; } render(); return; }

  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const act = btn.dataset.act;
  const a = artefacts();

  switch (act) {
    case 'enter': state.authed = true; persist(); location.hash = '#/dashboard'; render(); break;
    case 'demo': await loadDemo(); break;
    case 'clear': clearAll(); break;
    case 'close-drawer': state.selected = null; render(); break;
    case 'pick-files': $('#fileIn').click(); break;
    case 'pick-folder': $('#dirIn').click(); break;
    case 'sample-paste': $('#pCode').value = SAMPLE; break;
    case 'scan-paste': scanPasted($('#pCode').value, $('#pName').value, formMeta()); break;
    case 'reset-filters': Object.assign(state.inv, { q: '', risk: '', algo: '', app: '', env: '', lib: '', page: 1 }); render(); break;
    case 'filter-app': Object.assign(state.inv, { app: btn.dataset.val, page: 1 }); location.hash = '#/inventory'; render(); break;
    case 'prev': state.inv.page = Math.max(1, state.inv.page - 1); render(); break;
    case 'next': state.inv.page += 1; render(); break;
    case 'reset-assumptions': state.assumptions = { migrationYears: 4, dataLifetimeYears: 10, threatHorizonYears: 12 }; persist(); render(); break;
    case 'export-inv-csv': download('ecdat-inventory.csv', inventoryCSV(filtered().length ? filtered() : a), 'text/csv'); break;
    case 'export-inv-json': download('ecdat-analysis.json', JSON.stringify({ meta: state.result.meta, stats: state.result.stats, assumptions: state.assumptions, mosca: moscaNow(), artefacts: a }, null, 2), 'application/json'); break;
    case 'cbom-json': download('ecdat-cbom.json', JSON.stringify(state.result.cbom, null, 2), 'application/json'); break;
    case 'cbom-csv': download('ecdat-cbom.csv', cbomToCSV(state.result.cbom), 'text/csv'); break;
    case 'cbom-readable': printable('ECDAT CBOM — human-readable', technicalReport(a, state.result.cbom, moscaNow(), state.result.meta)); break;
    case 'rep-exec': download('ecdat-executive-report.txt', executiveReport(a, moscaNow(), state.result.meta)); break;
    case 'rep-tech': download('ecdat-technical-report.txt', technicalReport(a, state.result.cbom, moscaNow(), state.result.meta)); break;
    case 'rep-exec-print': printable('ECDAT Executive Report', executiveReport(a, moscaNow(), state.result.meta)); break;
    case 'rep-tech-print': printable('ECDAT Technical Report', technicalReport(a, state.result.cbom, moscaNow(), state.result.meta)); break;
  }
});

function formMeta() {
  const g = (id, d) => ($(id)?.value ?? d);
  return {
    application: g('#mApp', 'Uploaded Project') || 'Uploaded Project',
    environment: g('#mEnv', 'Unspecified'),
    criticality: g('#mCrit', 'medium'),
    dataLifetimeYears: Math.max(0, Number(g('#mLife', 5)) || 5),
    exposure: g('#mExp', 'internal'),
    dependencies: []
  };
}

document.addEventListener('input', (e) => {
  const f = e.target.dataset.f;
  if (f) {
    if (f === 'cbomQ') { state.cbomQ = e.target.value; debounceRender(e.target); return; }
    if (f === 'size') { state.inv.size = Number(e.target.value); state.inv.page = 1; render(); return; }
    state.inv[f] = e.target.value; state.inv.page = 1; debounceRender(e.target); return;
  }
  const ak = e.target.dataset.a;
  if (ak) {
    const v = Number(e.target.value);
    if (!isNaN(v) && v >= 0) { state.assumptions[ak] = v; persist(); debounceRender(e.target); }
  }
});

let tmr;
function debounceRender(el) {
  clearTimeout(tmr);
  const id = el.dataset.f || el.dataset.a, pos = el.selectionStart, tag = el.tagName;
  tmr = setTimeout(() => {
    render();
    const again = document.querySelector(`[data-f="${id}"],[data-a="${id}"]`);
    if (again && again.tagName === tag) { again.focus(); try { again.setSelectionRange(pos, pos); } catch (_) { } }
  }, 230);
}

document.addEventListener('change', async (e) => {
  if (e.target.id === 'fileIn' || e.target.id === 'dirIn') {
    const files = [...e.target.files];
    if (!files.length) return;
    const meta = formMeta();
    state.busy = `Reading and analysing ${files.length} file(s) locally…`; render();
    await new Promise(r => setTimeout(r, 60));
    await scanFiles(files, meta);
  }
});

document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && state.selected) { state.selected = null; render(); } });

function wireDrop() {
  const d = $('#drop'); if (!d) return;
  d.addEventListener('click', (e) => { if (!e.target.closest('button')) $('#fileIn').click(); });
  ['dragenter', 'dragover'].forEach(t => d.addEventListener(t, e => { e.preventDefault(); d.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(t => d.addEventListener(t, e => { e.preventDefault(); d.classList.remove('over'); }));
  d.addEventListener('drop', async (e) => {
    const files = [...(e.dataTransfer?.files || [])];
    if (!files.length) return;
    const meta = formMeta();
    state.busy = `Reading and analysing ${files.length} item(s) locally…`; render();
    await new Promise(r => setTimeout(r, 60));
    await scanFiles(files, meta);
  });
}

const SAMPLE = `from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.hazmat.primitives import hashes
import hashlib

# Settlement signing key
key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

SESSION_CIPHER = "AES-128-CBC"
ARCHIVE_CIPHER = "AES-256-GCM"
TLS_VERSION = "TLSv1.2"
CERT_PATH = "/etc/app/certs/service.pem"

def legacy_id(v):
    return hashlib.md5(v.encode()).hexdigest()

def agree(priv, peer):
    return priv.exchange(ec.ECDH(), peer)`;

/* ============================ render ============================ */
function render() {
  const app = $('#app');
  const page = route();
  app.innerHTML = state.authed ? shell(page) : loginView();
  if (state.authed && page === 'discovery') wireDrop();
  document.title = state.authed ? `ECDAT · ${PAGES[page].title}` : 'ECDAT — Enterprise Cryptographic Discovery & Analysis Tool';
}

restore();
render();
