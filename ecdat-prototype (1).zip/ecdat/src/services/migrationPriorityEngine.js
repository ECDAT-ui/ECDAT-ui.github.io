/**
 * Migration priority = weighted blend of quantum risk, business value and effort.
 * priorityScore (0-100) = 0.40*riskScore + 0.20*criticality + 0.15*dataLifetime
 *                       + 0.10*exposure + 0.10*dependencyPressure + 0.05*cryptoImportance
 * Migration complexity does NOT increase priority score directly; it is reported
 * separately so teams can distinguish "urgent" from "slow to fix".
 */
const CRIT = { critical: 100, high: 75, medium: 50, low: 25 };
const EXPO = { 'internet-facing': 100, partner: 70, internal: 40, isolated: 15 };
const IMPORTANCE = { certificate: 100, protocol: 90, 'key-establishment': 95, signature: 85, 'public-key': 85, 'key-material': 70, 'symmetric-cipher': 55, kdf: 45, mac: 40, hash: 40 };

export const PRIORITY_WEIGHTS = { risk: 0.40, criticality: 0.20, dataLifetime: 0.15, exposure: 0.10, dependencies: 0.10, importance: 0.05 };

export function prioritise(artefacts) {
  const scored = artefacts.map(a => {
    const parts = {
      risk: a.risk.score,
      criticality: CRIT[a.criticality] ?? 50,
      dataLifetime: Math.min(100, ((a.dataLifetimeYears ?? 5) / 15) * 100),
      exposure: EXPO[a.exposure] ?? 40,
      dependencies: Math.min(100, (a.dependencies?.length || 0) * 20),
      importance: IMPORTANCE[a.primitive] ?? 50
    };
    const priorityScore = Math.round(
      Object.entries(PRIORITY_WEIGHTS).reduce((s, [k, w]) => s + parts[k] * w, 0)
    );
    return { ...a, priorityScore, priorityParts: parts };
  });

  scored.sort((x, y) => y.priorityScore - x.priorityScore || y.risk.score - x.risk.score || x.id.localeCompare(y.id));
  scored.forEach((a, i) => { a.priorityRank = i + 1; a.priorityBand = band(a.priorityScore); });
  return scored;
}

export function band(s) {
  if (s >= 70) return 'P1 — Begin migration planning now';
  if (s >= 55) return 'P2 — Plan hybrid migration';
  if (s >= 40) return 'P3 — Scheduled upgrade';
  return 'P4 — Monitor';
}
