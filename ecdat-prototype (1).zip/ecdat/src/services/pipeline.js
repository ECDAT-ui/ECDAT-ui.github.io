import { discover } from './discoveryEngine.js';
import { scoreArtefact } from './quantumRiskEngine.js';
import { recommend } from './pqcRecommendationEngine.js';
import { prioritise } from './migrationPriorityEngine.js';
import { generateCBOM } from './cbomGenerator.js';

/** DISCOVER → ANALYSE → RISK → RECOMMEND → PRIORITISE → CBOM */
export function runPipeline(files, meta = {}) {
  const discovery = discover(files, { source: meta.source });
  const withRisk = discovery.artefacts.map(a => {
    const risk = scoreArtefact(a);
    return { ...a, risk, recommendation: recommend(a, risk) };
  });
  const artefacts = prioritise(withRisk);
  const analysis = { ...discovery, artefacts };
  const cbom = generateCBOM(analysis, meta);
  return { artefacts, libraries: discovery.libraries, cbom, meta, stats: { filesScanned: discovery.filesScanned, linesScanned: discovery.linesScanned, scannedAt: discovery.scannedAt } };
}
