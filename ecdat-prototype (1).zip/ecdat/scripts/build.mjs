// The app has no build step: it ships as ES modules the browser loads directly.
// "build" therefore runs the engine tests and stages a clean dist/ for deployment.
import { cp, rm, mkdir, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';

execFileSync(process.execPath, ['tests/run-tests.mjs'], { stdio: 'inherit' });

await rm('dist', { recursive: true, force: true });
await mkdir('dist', { recursive: true });
for (const p of ['index.html', 'assets', 'src']) await cp(p, `dist/${p}`, { recursive: true });
await writeFile('dist/.nojekyll', '');
await cp('index.html', 'dist/404.html'); // hash routing fallback for deep links
console.log('\nBuilt -> dist/  (static, no bundler, works from any subdirectory)');
